function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async function Copied_succesfully(button) {
    const textDiv = button.parentElement.querySelector('.copy-text');
    const text = textDiv.innerText;
    const tempTextArea = document.createElement('textarea');
    tempTextArea.value = text;
    document.body.appendChild(tempTextArea);
    tempTextArea.select();
    document.execCommand('copy');
    document.body.removeChild(tempTextArea);
    const copiedDiv = document.getElementById("Copied");
    copiedDiv.style.display = "block";
    await sleep(2000);
    copiedDiv.style.display = "none";
  }