# import os

# a = "F:\\SONGS\\"
# r = os.listdir(a)
# print(r)

r = ['DJ', 'English Song', 'Hindi Song','Long', 'Slow-Reversed', 'Stand Up Comdey']
for i in range(5):
    print(f"F:\\Songs\\{r[i]}")