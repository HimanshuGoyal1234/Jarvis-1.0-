from os import getcwd
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--use-fake-ui-for-media-stream")
chrome_options.add_argument("--")
driver = webdriver.Chrome(service=Service(executable_path=r"G:\\FREEEEEEEE\\Driver\\chromedriver.exe"),options=chrome_options)
website=  f"{getcwd()}\\LISTEN\\listen.html"
driver.get(website)
def listen():
    start_button = WebDriverWait(driver,timeout=10).until(EC.element_to_be_clickable((By.ID,"start")))
    start_button.click()
    output_text = ""
    try:
        with open("output.txt","w") as output_file:
            while True:
                output_element = WebDriverWait(driver,timeout=10).until(EC.presence_of_element_located((By.ID,"output")))
                current_text = output_element.text.strip()
                if current_text!=output_text:
                    output_text = current_text
                    output_file.write(output_text)
                    output_file.write(output_text + "\r")
                    if "jarvis" in output_text.lower():
                        print("hello sir")
                time.sleep(0.5)
    except KeyboardInterrupt:
        pass
# if __name__=="__main__":
#     try:
#         Listen()
#     finally:
#         driver.quit()