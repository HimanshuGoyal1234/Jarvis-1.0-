import datetime
from random import choice
import pyttsx3
from time import sleep
def _drive_selection_():
    er = open(f"G:\\MYJARVIS\\important_things\\drive.txt", "r")
    re = er.readline()
    return re
def alpha(audio):
    engine = pyttsx3.init("sapi5")
    voices = engine.getProperty("voices")
    engine.setProperty("rate", 180)
    voice = open(f"{_drive_selection_()}\\important_things\\voice.txt", "r")
    voice = voice.readline()
    voice = int(voice)
    engine.setProperty("voice", voices[voice].id)
    ere = f"{audio}..."
    print(ere)
    engine.say(ere)
    engine.runAndWait()
def alarm_______():
    _query_name = open(f"{_drive_selection_()}\\alarm\\query_name.txt","r")
    query_name = _query_name.readline()
    r =  open(f"{_drive_selection_()}\\alarm\\query_for_alarm.txt", "r")
    current_time = r.readline()
    er = open(f"{_drive_selection_()}\\alarm\\query_for_alarm.txt", "r")
    if current_time == "":
        return
    dfdf = er.readline()
    current_time = current_time[13:-5]
    time_components = current_time.split(":")
    hours = int(time_components[0])
    minutes = int(time_components[1])
    am_pm = dfdf[18:]
    if am_pm == 'p.m.':
        if hours >= 1 and hours <= 11:
            hours += 12
    print(f"alarm set: {hours}:{minutes} {am_pm}")
    now = datetime.datetime.now()
    if now.hour == hours and now.minute >= minutes:
        er = open(f"{_drive_selection_()}\\alarm\\query_for_alarm.txt","w")
        er.write("")
        er.close()
        for i in range(3):
            alpha(f"{query_name} sir\nalarm time sir")
        exit()
while True:
    sleep(10)
    alarm_______()