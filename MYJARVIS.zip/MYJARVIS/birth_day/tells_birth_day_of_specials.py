master = "himanshu goyal"  # write your name in small letters
import datetime
import json
from all_important_functions import takeCommand,_drive_selection_,alpha

file_path = f"{_drive_selection_()}\\birth_day\\tells_birth_day_of_specials.json"
with open(file_path, "r") as file:
    json_data = json.load(file)
def is_birthday(birthday_date):
    today = datetime.datetime.now().date()
    if today.month == birthday_date.month and today.day == birthday_date.day:
        return True
    else:
        return False
def main():
    with open(f"{_drive_selection_()}\\birth_day\\last_date.txt", "r") as file:
        last_printed_date = file.read().strip()
    current_date = datetime.date.today().isoformat()
    if last_printed_date != current_date:
        with open(f"{_drive_selection_()}\\birth_day\\last_date.txt", "w") as file:
            file.write(current_date)
        for person, birth_date_str in json_data.items():
            birth_date = datetime.datetime.strptime(birth_date_str, "%m-%d").date()
            if is_birthday(birth_date):
                if person != master:
                    import Dialogs.Dialog as Dialog
                    Dialog._main_(Dialog.what_today_is)
                    er = takeCommand().lower()
                    if "no" in er or "you tell me" in er:
                        alpha(f"Today is {person}'s birthday!")
                    elif "skip it" in er or "i don't care" in er:
                        alpha("Okay, sir.")
                        alpha(f"just kindly for your information, Today is {person}'s birthday")
                    else:
                        pass
                else:
                    alpha(
                            "Happy Birthday Sir,\nI hope your day is filled with joy, laughter, and wonderful moments. that become cherished memories. May this new year of your life bring you everything you've been wishing for I hope you'll achieve all things"
                    )
file_path = f"{_drive_selection_()}\\birth_day\\tells_birth_day_of_specials.json"
with open(file_path, "r") as file:
    json_data = json.load(file)
def tell_birthdate():
    ep = open(f"{_drive_selection_()}\\important_things\\query.txt", "r")
    ep = ep.readline()
    if "what is the birthdate of " in ep:
        splt = ep.split("what is the birthdate of ")
        splt = splt[1]
    if "what is the birthday of " in ep:
        splt = ep.split("what is the birthday of ")
        splt = splt[1]
    try:
        string = json_data[splt]
        st = str(string)
        st = st.split("-")
        dicts = {
                1: "January",
            2: "February",
            3: "March",
            4: "April",
            5: "May",
            6: "June",
            7: "July",
            8: "August",
            9: "September",
            10: "October",
            11: "November",
            12: "December",
        }
        months = st[0]
        month_number = int(months)
        if 1 <= month_number <= 12:
            month = dicts[month_number]
        date = st[1]
        alpha(f"Month: {month}\nDate: {date}")
    except:
        alpha("not found")
# tell_birthdate()