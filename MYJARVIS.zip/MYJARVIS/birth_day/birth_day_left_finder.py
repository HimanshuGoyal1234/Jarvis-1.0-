import datetime
from all_important_functions import _drive_selection_
from all_important_functions import alpha
def birth_Day_finder():
    birth_month = int(input("month: "))
    birth_day = int(input("day: "))
    today = datetime.datetime.now()
    # Create a datetime object for your birthday this year
    next_birthday = datetime.datetime(today.year, birth_month, birth_day)
    # If your birthday has passed this year, calculate the next birthday for next year
    if next_birthday < today:
        next_birthday = datetime.datetime(today.year + 1, birth_month, birth_day)
    # Calculate the difference in days
    days_until_birthday = (next_birthday - today).days
    alpha(f"Days left for your birthday: {days_until_birthday}")
def how_many_days_left_to_my_birth_day():
    birth_month = 5
    birth_day = 10
    today = datetime.datetime.now()
    next_birthday = datetime.datetime(today.year, birth_month, birth_day)
    if next_birthday < today:
        next_birthday = datetime.datetime(today.year + 1, birth_month, birth_day)
    days_until_birthday = (next_birthday - today).days
    alpha(f"Days left for your birthday: {days_until_birthday}")
