import importlib
import json
from random import choice
import random


from random import choice
from all_important_functions import takeCommand


from all_important_functions import _drive_selection_ 
from all_important_functions import alpha
def main():
    hiiii = ["Whose phone number are you looking for?",
             "Whose phone number you are looking for?",
            "Tell me the name of the person"]
    re = choice(hiiii)
    alpha(f"{re}")
    oi = f"{_drive_selection_()}\\Phone_Numbers\\saved_phone_number.json"
    splt = takeCommand().lower()
    try:
        with open(oi,"r") as file:
            data = json.load(file)
        iii = splt.split(" ")
        poi = iii[0]
        alpha(f"Sir, {poi} phone number is {data[splt]}")
    except KeyError:
        alpha("I'm sorry, Number not found")
# main()