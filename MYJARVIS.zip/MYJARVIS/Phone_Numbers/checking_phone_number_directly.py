import json
from random import choice


from all_important_functions import _drive_selection_ 
from all_important_functions import alpha
def main():
    oi = f"{_drive_selection_()}\\Phone_Numbers\\saved_phone_number.json"
    ope = open(f"{_drive_selection_()}\\important_things\\query.txt","r")
    ope = ope.readline()
    ope = ope.split("what is the phone number of ")
    splt = ope[1]
    try:
        with open(oi,"r") as file:
            data = json.load(file)
        iii = splt.split(" ")
        poi = iii[0]
        alpha(f"Sir, {poi} phone number is {data[splt]}")
    except KeyError:
        alpha("I'm sorry, Number not found")
# main()