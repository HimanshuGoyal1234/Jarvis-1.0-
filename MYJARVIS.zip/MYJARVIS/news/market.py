import requests
from bs4 import BeautifulSoup

from all_important_functions import _drive_selection_ 
from all_important_functions import alpha
def market():
    url = 'https://indianexpress.com/section/business/market/'
    response = requests.get(url)
    if response.status_code == 200:
        pass
    else:
        alpha("Failed to retrieve data. Status code:", response.status_code)
        exit()
    soup = BeautifulSoup(response.content, 'html.parser')
    headlines = soup.find_all('h2', class_='title')
    for headline in headlines[:5]:
        alpha(headline.text.strip())
