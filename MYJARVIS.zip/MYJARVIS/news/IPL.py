import requests
from bs4 import BeautifulSoup

from all_important_functions import _drive_selection_ 
from all_important_functions import alpha

def IPL():
    # Define the URL of the news website
    url = 'https://indianexpress.com/section/sports/ipl/'

    # Send a GET request to the website
    response = requests.get(url)

    # Check if the request was successful
    if response.status_code == 200:
        # alpha("Request successful")
        pass
    else:
        alpha("Failed to retrieve data. Status code:", response.status_code)
        exit()

    # Parse the HTML content of the webpage
    soup = BeautifulSoup(response.content, 'html.parser')

    # Find and extract news headlines
    headlines = soup.find_all('h2', class_='title')

    # Print the first three headlines
    for headline in headlines[:5]:
        alpha(headline.text.strip())
