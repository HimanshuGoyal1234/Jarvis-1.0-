import random
import subprocess
import speech_recognition as sr
import pyperclip
import datetime
import os
import json
import importlib
from pyautogui import keyDown, press, typewrite, keyUp
from time import sleep
from random import choice
import psutil, pyttsx3
from Automations.automations import *
engine = pyttsx3.init("sapi5")
voices = engine.getProperty("voices")
engine.setProperty("rate", 180)
def _drive_selection_():
    er = open(f"G:\\MYJARVIS\\important_things\\drive.txt", "r")
    re = er.readline()
    return re
def simple_answer():
    import Dialogs.Dialog as Dialog
    importlib.reload(Dialog)
    Dialog.main(Dialog.success_open)
def alpha(audio):
    engine = pyttsx3.init("sapi5")
    voices = engine.getProperty("voices")
    engine.setProperty("rate", 180)
    voice = open(f"{_drive_selection_()}\\important_things\\voice.txt", "r")
    voice = voice.readline()
    voice = int(voice)
    engine.setProperty("voice", voices[voice].id)
    ere = f"{audio}..."
    print(ere)
    engine.say(ere)
    engine.runAndWait()
def takeCommand():
    input_or_takecommand = open(f"{_drive_selection_()}\\important_things\\input_or_takecommand.txt", "r")
    input_or_takecommand = input_or_takecommand.readline()
    if input_or_takecommand == "0":
        import Dialogs.Dialog as Dialog
        importlib.reload(Dialog)
        while True:
            r = sr.Recognizer()
            count = 0
            while count < 3:
                with sr.Microphone() as source:
                    Dialog.listening()
                    r.pause_threshold = 1
                    r.energy_threshold = 8000
                    audio = r.listen(source)
                try:
                    Dialog.recognizing()
                    query = r.recognize_google(audio, language="en-in")
                    print(f"User said: {query}\n")
                    return query.lower()
                except Exception as e:
                    count += 1
                    Dialog.say_that_again()
    elif input_or_takecommand == "1":
        query = input()
        return query.lower()
def delete_file_folder():
    alpha("sir, give me a path")
    import function.delete_anything as delete_anything
    importlib.reload(delete_anything)
    delete_anything.delete()
def send_message_on_whatsapp():
    import function.send_message_on_whatsapp as send_message_on_whatsapp
    importlib.reload(send_message_on_whatsapp)
    send_message_on_whatsapp.send_message_on_whatsapp__()
def send_message_on_instagram():
    import function.send_message_on_instagram as send_message_on_instagram
    importlib.reload(send_message_on_instagram)
    send_message_on_instagram.send_message_on_instagram()
def _search_wikipedia():
    import function.search_on_wikipendia as search_on_wikipendia
    importlib.reload(search_on_wikipendia)
    search_on_wikipendia.search_wikipedia()
def find_phone_number():
    import Phone_Numbers.checking_phone_number as checking_phone_number
    importlib.reload(checking_phone_number)
    checking_phone_number.main()
def add_new_number():
    import function.add_new_phone_number as add_new_phone_number
    importlib.reload(add_new_phone_number)
    add_new_phone_number.main()
def checking_phone_number_directly():
    import Phone_Numbers.checking_phone_number_directly as checking_phone_number_directly
    importlib.reload(checking_phone_number_directly)
    checking_phone_number_directly.main()
def chrome(url):
    chrome_path = "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe"  # Path to Chrome executable
    subprocess.Popen([chrome_path, url])
def _play_song_():
    import Songs.songs as songs
    importlib.reload(songs)
    songs.main()
def save_your_code():
    import function.save_your_every_code as save_your_every_code
    importlib.reload(save_your_every_code)
    save_your_every_code.main()
def Google_search():
    import _google.__google__ as __google___
    importlib.reload(__google___)
    __google___.main()
def wishMe():
    import function.wish_me as wish_me
    importlib.reload(wish_me)
    wish_me.__wish_ME__()
def alarm_when_sleep():
    os.startfile(f"{_drive_selection_()}\\alarm\\alarm__.py")
def _sleep():
    import Dialogs.Dialog as Dialog
    importlib.reload(Dialog)
    Dialog.main(Dialog.___sleep)
    query_for_alarm = open("G:\\MYJARVIS\\alarm\\query_for_alarm.txt", "r")
    queryoo = query_for_alarm.readline()
    if queryoo == "":
        pass
    else:
        alarm_when_sleep()
    sleep_sound()
    input("")
    wake_sound()
    welcome()
def change_name():
    simple_answer()
    alpha("which name do you like to call me")
    import function.change_name as change_name
    importlib.reload(change_name)
    change_name.change__name()
def Copy_my_gmail():
    with open(
            f"{_drive_selection_()}\\information_of_you\\data.json", "r", encoding="utf-8"
    ) as file:
        load = load(file)
    er = load["what is my gmail id"]
    er = str(er)
    pyperclip.copy(er)
def save_information_by_me(data):
    file_path = f"{_drive_selection_()}\\information_of_you\\information_of_me.json"
    try:
        with open(file_path, "r") as file:
            existing_data = json.load(file)
    except FileNotFoundError:
        existing_data = {}
    existing_data.update(data)
    with open(file_path, "w") as file:
        json.dump(existing_data, file, indent=4)
def save_information_by_me_main():
    alpha("what is the question")
    a = takeCommand().lower()
    alpha("what is the answer")
    b = takeCommand().lower()
    if a == "":
        a = ""
        b = ""
    if b == "":
        b = ""
        a = ""
    new_data = {
            f"{a}": f"{b}",
    }
    print(f"Question: {a}\nAnswer:{b}")
    save_information_by_me(data=new_data)
    data_writing_sound()
    alpha("done Sir")
def Data_analyzer():
    def load_data(file_path):
        with open(file_path, "r", encoding="utf-8") as file:
            data = json.load(file)
        return data
    def main():
        try:
            data_file = f"{_drive_selection_()}\\information_of_you\\data.json"
            data = load_data(data_file)
            user_input = query
            handle_query(user_input, data)
        except Exception as e:
            print(f"An error occurred: {e}")
    def handle_query(query, data):
        if query.lower() in data:
            alpha(data[query.lower()])
        else:
            pass
    main()
def your_data_analyzer():
    import function.your_data_analyzer as your_data_analyzer
    importlib.reload(your_data_analyzer)
    your_data_analyzer.main()
def battery_percentage():
    battery = psutil.sensors_battery()
    return battery.percent
def __query__():
    er = open(
            f"{_drive_selection_()}\\important_things\\query.txt", "w", encoding="utf-8"
    )
    er.writelines(query)
    er.close()
def __query__for_alarm():
    er = open(f"{_drive_selection_()}\\alarm\\query_for_alarm.txt", "w")
    er.writelines(query)
    er.close()
def alarm():
    _query_name = open(f"{_drive_selection_()}\\alarm\\query_name.txt", "r")
    query_name = _query_name.readline()
    r = open(f"{_drive_selection_()}\\alarm\\query_for_alarm.txt", "r")
    current_time = r.readline()
    er = open(f"{_drive_selection_()}\\alarm\\query_for_alarm.txt", "r")
    if current_time == "":
        return
    dfdf = er.readline()
    current_time = current_time[13:-5]
    time_components = current_time.split(":")
    hours = int(time_components[0])
    minutes = int(time_components[1])
    am_pm = dfdf[18:]
    if am_pm == "p.m.":
        if hours >= 1 and hours <= 11:
            hours += 12
    print(f"alarm set: {hours}:{minutes} {am_pm}")
    now = datetime.datetime.now()
    if now.hour == hours and now.minute >= minutes:
        er = open(f"{_drive_selection_()}\\alarm\\query_for_alarm.txt", "w")
        er.write("")
        er.close()
        alarm_sound()
        sleep(5)
        alpha(f"{query_name} sir\nalarm time sir")
def get_cpu_speed():
    import function.get_speed_of_cpu as get_cpu_speed_of_cpu
    importlib.reload(get_cpu_speed_of_cpu)
    get_cpu_speed_of_cpu.cpu_speed()
def __close__():
    file_path = f"{_drive_selection_()}\\important_things\\query.txt"
    with open(file_path, "r") as file:
        contents = file.read()
        words = contents.split()
        pi = words[-1]
        err = pi
        _dict_ = {
                "mpc": "mpc-hc64",
            "notepad": "notepad",
            "chrome": "chrome",
            "photos": "Microsoft.Photos",
            "calculator": "calculatorapp",
            "vlc": "vlc",
            "photos": "photosapp",
            "edge": "msedge",
            "instagram": "msedge",
            "camera": "windowscamera",
            "whatsapp": "whatsapp",
            "store": "winstore.app",
        }
        er = _dict_[err]
        os.system(f"taskkill /f /im {er}.exe")
def _screen_shot():
    import function.screen_shot as screen_shot
    importlib.reload(screen_shot)
    screen_shot._screen_shot_()
    capture_screenshot()
    alpha("captured screen shot")
def __restart_system():
    import function.__restart_system__ as __restart_system__
    importlib.reload(__restart_system__)
    __restart_system__.startfunction()
    exit()
def _add_birth_day():
    import birth_day.add_birth_day as add_birth_day
    importlib.reload(add_birth_day)
    add_birth_day.save_information_by_me_main()
def birth_day_finder():
    alpha("tell me these things")
    import birth_day.birth_day_left_finder as birth_day_left_finder
    importlib.reload(birth_day_left_finder)
    birth_day_left_finder.birth_Day_finder()
def specials_birth_day_and_festivals():
    import birth_day.tells_birth_day_of_specials as tells_birth_day_of_specials
    importlib.reload(tells_birth_day_of_specials)
    tells_birth_day_of_specials.main()
    import festivals.main_file as main_file
    importlib.reload(main_file)
    main_file.main()
def tell_birthdate():
    import birth_day.tells_birth_day_of_specials as tell_birthdate
    importlib.reload(tell_birthdate)
    tell_birthdate.tell_birthdate()
def to_my_birthday():
    import birth_day.birth_day_left_finder as birth_day_left_finder
    importlib.reload(birth_day_left_finder)
    birth_day_left_finder.how_many_days_left_to_my_birth_day()
def _add_festival():
    import festivals.add_festival as add_festival
    importlib.reload(add_festival)
    add_festival.save_information_by_me_main()
def _starting_password():
    import function.starting_password_ as starting_password_
    importlib.reload(starting_password_)
    starting_password_.enter_password()
def youtube_video_download_():
    er = open(f"{_drive_selection_()}\\important_things\\youtube_audio_video.txt", "w")
    simple_answer()
    alpha(f"please copy url of than video then i download it  ")
    inn = input("URL: ")
    er.writelines(inn)
    er.close()
    os.startfile(f"{_drive_selection_()}\\function\\youtube_video_downloader.py")
def youtube_audio_download_():
    er = open(f"{_drive_selection_()}\\important_things\\youtube_audio_video.txt", "w")
    simple_answer()
    alpha(f"please copy url of than audio then i download it")
    inn = input("URL: ")
    er.writelines(inn)
    er.close()
    os.startfile(f"{_drive_selection_()}\\function\\youtube_audio_downloader.py")
    alpha("downloading start")
def search_step_wise():
    import function.search_step_wise as search_step_wise
    importlib.reload(search_step_wise)
    search_step_wise.step_wise()
def user_name_of_instagram():
    import instagram.user_name as user_name
    importlib.reload(user_name)
    user_name.user_name()
def instagram_dp_downloader():
    import instagram.instagram_dp_downloader as instagram_dp_downloader
    importlib.reload(instagram_dp_downloader)
    instagram_dp_downloader.download_instagram_dp()
def random_reels_on_instagram():
    import instagram.random_funny_reels as random_funny_reels
    importlib.reload(random_funny_reels)
    random_funny_reels.random_reel()
def news():
    er = open(f"{_drive_selection_()}\\query.txt", "r")
    read_line = er.readline()
    split = read_line.split("news of ")
    whose = split[1]
    if whose == "ipl":
        import news.IPL as IPL
        importlib.reload(IPL)
        IPL.IPL()
    elif whose == "banking and finance":
        import news.banking_and_finance as banking_and_finance
        importlib.reload(banking_and_finance)
        banking_and_finance.banking_finance()
    elif whose == "market":
        import news.market as market
        importlib.reload(market)
        market.IPL()
    else:
        print("🤔")
        pass
def _movies_():
    import MMovies.movies_ as movies_
    importlib.reload(movies_)
    movies_.main()
def random_tell_movies_for_watch():
    import MMovies.random_movies_for_watch as random_movies_for_watch
    importlib.reload(random_movies_for_watch)
    random_movies_for_watch.main()
def __search__():
    import Automations.automations as automat
    importlib.reload(automat)
    automat.search()
def play_IGI_game():
    simple_answer()
    import function.play_IGI_game as play_IGI_game
    importlib.reload(play_IGI_game)
    play_IGI_game.play()
    _sleep()
def search_on_chatgpt():
    import function.search_on_chatgpt as search_on_chatgpt
    importlib.reload(search_on_chatgpt)
    search_on_chatgpt.main()
def check_weather_today():
    import _google.check_today_weather as check_today_weather
    importlib.reload(check_today_weather)
    check_today_weather.main()
def copy_file_in_hindi_song_folder():
    import function.copy_file_in_hindi_song_folder as copy_file_in_hindi_song_folder
    importlib.reload(copy_file_in_hindi_song_folder)
    copy_file_in_hindi_song_folder.main()
def clean_temp():
    import function.clean_temp as clean_temp
    importlib.reload(clean_temp)
    clean_temp.main()
def clean_recycle_bin():
    import function.clean_recycle_bin as clean_recycle_bin
    importlib.reload(clean_recycle_bin)
    clean_recycle_bin.main()
def open_web_dev_vs_code():
    import function.open_web_dev_vs_code as open_web_dev_vs_code
    importlib.reload(open_web_dev_vs_code)
    open_web_dev_vs_code.main()
def refresh_my_window():
    import function.auto_refresh as auto_refresh
    importlib.reload(auto_refresh)
    auto_refresh.main()
def start_end_recording():
    import function.start_end_recording as start_end_recording
    importlib.reload(start_end_recording)
    start_end_recording.main()
def _425():
    import os, random
    path = "F:\\zMMM\\Nandu"
    list_ = os.listdir(path)
    r = len(list_)
    main = random.randint(0, r - 1)
    os.startfile(os.path.join(path, list_[main]))
def open_web_series_folder():
    import function.open_web_series as open_web_series
    importlib.reload(open_web_series)
    open_web_series.main()
def check_internet_speed():
    import function.check_interent_speed as check_interent_speed
    importlib.reload(check_interent_speed)
    check_interent_speed.test_internet_speed()
def open_applications():
    import function.open_applications as open_applications
    importlib.reload(open_applications)
    open_applications.main()
def calculator():
    er = open(f"{_drive_selection_()}\\important_things\\query.txt", "w")
    er.writelines(query[10:])
    er.close()
    import function.calculator as calculator
    importlib.reload(calculator)
    calculator.main()
def jokes():
    import function.__jokes__ as __jokes__
    importlib.reload(__jokes__)
    __jokes__.main()
def play_on_yt():
    simple_answer()
    import function.play_on_youtube as play_on_youtube
    importlib.reload(play_on_youtube)
    play_on_youtube.main()
def voice_changer():
    simple_answer()
    import function.change_voice as change_voice
    importlib.reload(change_voice)
    change_voice.main()
def audio_books():
    import function.random_books as random_books
    importlib.reload(random_books)
    random_books.main()
def history_creation():
    import function.history_creation as history_creation
    importlib.reload(history_creation)
    history_creation.main()
def translate():
    import function.translate as translate
    importlib.reload(translate)
    translate.main()
def binary_converter():
    import function.converting_into_binary as converting_into_binary
    importlib.reload(converting_into_binary)
    converting_into_binary.main()
def decode_binary_code_():
    simple_answer()
    alpha("please copy binary code then i convert it into text")
    a = input(">>>")
    er = open(f"{_drive_selection_()}\\important_things\\decoder_binary_code.txt", "w")
    poi = er.writelines(a)
    er.close()
    import function.decode_binary_code as decode_binary_code
    importlib.reload(decode_binary_code)
    decode_binary_code.main()
def sleep_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.sleep_sound()
def starting_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.starting_sound()
def restart_system_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.restart_system_sound()
def wake_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.wake_sound()
def data_writing_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.data_writing_sound()
def goodbye_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.goodbye_sound()
def capture_screenshot():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.capture_screenshot_sound()
def alarm_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.alarm_sound()
def battery():
    import battery.battery as __battery
    importlib.reload(__battery)
    __battery.main()
def find_my_ip_address():
    import function.find_ipaddress as find_ipaddress
    importlib.reload(find_ipaddress)
    find_ipaddress.main()
def crack_password():
    import function.crack_password as crack_password
    importlib.reload(crack_password)
    crack_password.main()
def battery_report():
    import function.generate_battery_report as generate_battery_report
    importlib.reload(generate_battery_report)
    generate_battery_report.main()
def generate_random_name():
    import function._random_name_ as _random_name_
    importlib.reload(_random_name_)
    _random_name_.main()
def generate_random_email():
    import function._random_emails as _random_emails
    importlib.reload(_random_emails)
    _random_emails.main()
def generate_random_password():
    import function._random_passwords as _random_passwords
    importlib.reload(_random_passwords)
    _random_passwords.main()
def country_code_finder():
    import function.country_code_finder as country_code_finder
    importlib.reload(country_code_finder)
    country_code_finder.main()
def goodBYE():
    import Dialogs.Dialog as Dialog
    importlib.reload(Dialog)
    Dialog.main(Dialog.goodbye)
def check_wifi():
    import function.check_wifi as wifi
    importlib.reload(wifi)
    wifi.main()
def welcome():
    import Dialogs.Dialog as Dialog
    importlib.reload(Dialog)
    Dialog.main(Dialog.welcomedlg)
def add_new_folder():
    import function.add_new_folder as add
    importlib.reload(add)
    add.main()
def add_new_website():
    import function.add_new_website as add
    importlib.reload(add)
    add.website_main()
def show_instagram_password():
    f = open("G:\\MYJARVIS\\important_things\\instagrampassword.txt", "r")
    r = len(f.readlines())
    f = open("G:\\MYJARVIS\\important_things\\instagrampassword.txt", "r")
    for i in range(r):
        print(f"{i+1}. {f.readline()}", end="")
    alpha("Here your all instagram id's and their passwords")
def add_new_song():
    import Songs.add_new_song as ans
    importlib.reload(ans)
    ans.add_song_main()
def save_web_devolpment_information():
    import function.web_development_save_informative_websites as save_web_devolpment_information
    importlib.reload(save_web_devolpment_information)
    save_web_devolpment_information.website_main()
def tables():
    import function.tables as table
    importlib.reload(table)
    table.main()

    
if __name__ == "__main__":
    # _starting_password()
    # starting_sound()
    # wishMe()
    # check_wifi()
    # specials_birth_day_and_festivals()
    # battery()
    while True:
        history_creation()
        query = takeCommand()
        alarm()
        __query__()
        if "good morning" in query or "goodmorning" in query:
            hour = int(datetime.datetime.now().hour)
            if hour >= 0 and hour < 12:
                alpha("Good Morning!, sir")
            else:
                alpha("I'm sorry  but at this time it is not a morning")
        elif "play" in query:
            _play_song_()
        elif "change the starting password" in query or "change the password" in query:
            _file = open(f"{_drive_selection_()}\\PS\\password.txt", "w")
            alpha("what should I set as password")
            _input = input("type: ")
            _file.write(_input)
            _file.close()
            alpha(f"{_input}, setted as a password")
        elif "clean temp" in query or "clean damp" in query:
            simple_answer()
            alpha(f"I'm going to clean")
            clean_temp()
            alpha("Done Sir")
            sleep(1)
        elif "goodbye" in query or "good bye" in query:
            goodBYE()
            goodbye_sound()
            exit()
        elif "formula number 425" in query:
            simple_answer()
            _425()
        elif "add new song in you" in query or "add new song into you" in query:
            add_new_song()
        elif "find phone number" in query or "find a phone number" in query or "find the phone number" in query :
            find_phone_number()
        elif "add new phone number" in query or "save a new phone number" in query or "save a new number" in query or "add a new phone number" in query :
            add_new_number()
        elif "restart system" in query or "restart program" in query:
            simple_answer()
            __restart_system()
        elif "download this youtube video" in query or "download youtube video" in query:
            youtube_video_download_()
        elif "open a instagram profile" in query or "open instagram profile" in query:
            user_name_of_instagram()
        elif "how many days left to my birthday" in query or "how many days left for my birthday" in query or "how many days left in my birthday" in query:
            to_my_birthday()
        elif "download audio of this youtube video" in query or "download youtube audio" in query or "download audio from this youtube video" in query :
            youtube_audio_download_()
        elif "add new birth date" in query or "save a new birthdate" in query or "add a new birthdate" in query or "add a new birthday" in query or "save a birthday" in query or "save new birthday" in query or "save birthday" in query or "save a new birthday" in query or "save a new birth date" in query or "add a new birth date" in query or "save new birth date" in query or "save birth date" in query :
            simple_answer()
            _add_birth_day()
        elif "open gmail" in query or "open my gmail" in query:
            chrome("gmail.com")
        elif "the weather today" in query or "todays weather" in query or "what is the weather today" in query or "whats the weather today" in query or "what is weather today" in query :
            check_weather_today()
        elif "download this instagram dp" in query or "download instagram dp" in query:
            instagram_dp_downloader()
        elif "add new festival" in query or "add a new festival" in query:
            simple_answer()
            _add_festival()
        elif "search on chat gpt" in query or "search on chat gpd" in query:
            search_on_chatgpt()
        elif "delete this folder" in query or "delete this file" in query or "delete folder" in query or "delete file" in query or "delete a file" in query or "delete a folder" in query :
            delete_file_folder()
        elif "close tab" in query or "close it" in query:
            keyDown("alt")
            press("f4")
            keyUp("alt")
        elif "close chrome" in query or "close notepad" in query or "close camera" in query or "close photos" in query or "close mpc" in query or "close instagram" in query :
            __close__()
        elif "switch tab" in query or "switch a tab" in query or "switch window" in query:
            keyDown("alt")
            press("tab")
            keyUp("alt")
        elif "mute volume" in query or "mute the volume" in query or query == "mute"or query == "jarvis mute":
            press("volumemute")
        elif "stop listening" in query or "go to sleep" in query or "jarvis sleep now" in query or "jao so jao" in query :
            _sleep()
        elif "add new function in you" in query or "add a new function in you" in query:
            alpha(
                    "(press enter) then new file will open and this file is closed\nif your done type (function is completed)"
            )
            input("")
            os.startfile(f"{_drive_selection_()}\\function\\add_new_function.py")
            exit()
        elif "save some information" in query or "save information" in query or "add new information" in query or "change information" in query or "save new information in you" in query or "add a new information in you" in query or "add a new information and you" in query or "save a new data in you" in query or "save a new information in you" in query :
            simple_answer()
            save_information_by_me_main()
        elif "take a screenshot" in query or "take screenshot" in query:
            _screen_shot()
        elif "play movie" in query:
            _movies_()
        elif "search on youtube" in query:
            __search__()
        elif "send message on whatsapp" in query:
            send_message_on_whatsapp()
        elif "clean recycle bin" in query:
            simple_answer()
            alpha(f"I'm going to clean")
            clean_recycle_bin()
            alpha("Done Sir")
        elif "search on google" in query:
            Google_search()
        elif "set an alarm" in query:
            simple_answer()
            alpha(f"but which name i should as it")
            a = input()
            er = open(f"{_drive_selection_()}\\alarm\\query_name.txt", "w")
            er.write(a)
            er.close()
            __query__for_alarm()
            simple_answer()
        elif "battery percentage in you" in query:
            alpha(f"My Battery is {battery_percentage()}")
        elif "how much faster as you work" in query or "how much faster work as you can" in query:
            get_cpu_speed()
        elif "type" in query:
            e = query[5:]
            print(e)
            typewrite(e)
        elif "activate how to do mode" in query:
            search_step_wise()
        elif "i am feeling bored can you do something" in query:
            alpha("oh I'll play a reel on instagram thats make you feel happy")
            random_reels_on_instagram()
        elif "play random reels on instagram" in query or "play some reels on instagram" in query or "play reels on instagram" in query :
            random_reels_on_instagram()
        elif "phone number of " in query:
            checking_phone_number_directly()
        elif "news of " in query:
            news()
        elif "search" in query:
            __search__()
        elif "what is the day today" in query or "what is day today" in query or "what day today is" in query :
            alpha(datetime.datetime.now().strftime("%A"))
        elif "search on wikipedia" in query:
            _search_wikipedia()
        elif "copy downloaded audio file in song folder" in query or "copy downloaded file in song folder" in query or "copy downloaded file to hindi song folder" in query:
            copy_file_in_hindi_song_folder()
        elif "what is the time" in query:
            strTime = datetime.datetime.now().strftime("%H:%M:%S")
            alpha(f"Sir, the time is {strTime}")
        elif "refresh my laptop" in query or "refresh my window" in query or "refresh window" in query :
            simple_answer()
            refresh_my_window()
        elif "start recording" in query or "stop recording" in query or "end recording" in query or "start screen recording" in query or "stop screen recording" in query :
            simple_answer()
            start_end_recording()
        elif "check internet speed" in query:
            check_internet_speed()
        elif "open " in query:
            open_applications()
        elif "calculate" in query:
            calculator()
        elif "crack some jokes" in query or "tell me some jokes" in query:
            jokes()
        elif "play on youtube" in query:
            play_on_yt()
        elif "change your voice" in query:
            voice_changer()
        elif query == "press enter":
            press("enter")
        elif "shut down my laptop" in query or "shutdown my laptop" in query:
            os.system("shutdown /s /f /t 0")
        elif "lock my laptop" in query or "lock window" in query:
            os.system("rundll32.exe user32.dll,LockWorkStation")
        elif "restart my laptop" in query:
            os.system("shutdown /r")
        elif "translate" in query:
            translate()
        elif "convert into binary" in query:
            binary_converter()
        elif "decode binary code" in query:
            decode_binary_code_()
        elif "what is the birthdate of " in query or "what is the birthday of " in query:
            tell_birthdate()
        elif "send a file with bluebooth" in query or "send the file with bluetooth" in query or "send file with bluetooth" in query:
            os.system("fsquirt.exe")
        elif "give me system information" in query or "tell me system information" in query:
            alpha("sir, give me a second")
            print(os.system("systeminfo"))
            alpha("sir this is your system information")
        elif "host name of my laptop" in query or "host name of my system" in query:
            os.system("hostname")
        elif "find my ip address" in query or "my ip address" in query:
            find_my_ip_address()
        elif "crack password" in query or "show me all wi-fi password" in query:
            crack_password()
        elif "generate battery report" in query:
            battery_report()
        elif "generate random name" in query:
            generate_random_name()
        elif "generate random email" in query:
            generate_random_email()
        elif "generate random password" in query:
            generate_random_password()
        elif "what is the code of country" in query or "what is the country code of india" in query:
            country_code_finder()
        elif "movies for watch" in query:
            random_tell_movies_for_watch()
        elif "add new code" in query or "save new code" in query or "save my code" in query or "save code" in query or "saving my code" in query or "saving code" in query :
            save_your_code()
        elif "press control tab" in query:
            keyDown("ctrl")
            press("tab")
            keyUp("ctrl")
        elif "volume up" in query:
            volume_up()
        elif "volume down" in query:
            volume_down()
        elif "forward" in query:
            seek_forward()
        elif "backward" in query:
            seek_backward()
        elif "go to start" in query or "go to home" in query or "seek from beginning" in query :
            seek_to_beginning()
        elif "go to end" in query or "seek from end" in query:
            seek_to_end()
        elif "go to previous chapter" in query or "seek from previous chapter" in query:
            seek_to_previous_chapter()
        elif "go to next chapter" in query or "seek from next chapter" in query:
            seek_to_next_chapter()
        elif "speed slow" in query or "speed low" in query or "speed decrease" in query:
            decrease_playback_speed()
        elif "speed fast" in query or "speed high" in query or "speed increase" in query:
            increase_playback_speed()
        elif "check youtube notifications" in query:
            check_notifications()
        elif "set this window on right side" in query:
            set_window_on_right_side()
        elif "set this window on left side" in query:
            set_window_on_left_side()
        elif "change your name" in query:
            change_name()
        elif "press enter" in query:
            press_enter()
        elif "copy my gmail id" in query:
            pyperclip.copy("hg9691249617@gmail.com")
            simple_answer()
        elif "pause" in query or "play" in query:
            play_pause()
        elif "exit full screen" in query:
            full_screen()
        elif "scroll up" in query:
            scroll_up()
        elif "scroll down" in query:
            scroll_down()
        elif "create a new folder in" in query or "add a new folder in" in query or "add new folder in" in query or "add a folder in" in query or "add folder in" in query or "create folder in" in query or "create a folder in" in query :
            add_new_folder()
        elif "reload page" in query:
            reload_page()
        elif "add a new website" in query or "add new website" in query or "add a website" in query or "add new website into you" in query:
            add_new_website()
        elif "show me my all instagram id password" in query or "show me all instagram id password" in query or "all instagram id password" in query:
            show_instagram_password()
        elif "save new web development website into you" in query:
            save_web_devolpment_information()
        elif "what is the table of " in query:
            tables()
        
        else:
            Data_analyzer()
            your_data_analyzer()
