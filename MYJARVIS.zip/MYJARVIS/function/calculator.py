
from all_important_functions import _drive_selection_
from all_important_functions import alpha
def main():
    string = open(f"{_drive_selection_()}\\important_things\\query.txt","r")
    string = string.readline()
    er = string.split(" ")
    ep = open(f"{_drive_selection_()}\\important_things\\query.txt","r")
    red = ep.readline()
    splt = red.split(" ")
    for i in range(len(splt)):
        if splt[i]=="x":
            splt[i] = " * "
        if splt[i]=="+":
            splt[i] = " + "
        if splt[i]=="-":
            splt[i] = " - "
        if splt[i]=="/":
            splt[i] = " / "
    poi = splt
    ep = open(f"{_drive_selection_()}\\important_things\\query.txt","w")
    red = ep.writelines(poi)
    ep.close()
    a = []
    b = []
    c = []
    d = [0]
    for i in range(len(er)):
        if i % 2 !=0:
            a.append(er[i])
        else:
            b.append((er[i]))
    if a[0]=="+":
        d.append(int(b[0]) + int(b[1]))
    if a[0]=="-":
        d.append(int(b[0]) - int(b[1]))
    if a[0]=="*":
        d.append(int(b[0]) * int(b[1]))
    if a[0]=="/":
        d.append(int(b[0]) / int(b[1]))
    for i in range(len(a) - 1):
        try:
            if a[i + 1]=="+":
                d.append(d[i + 1] + int(b[i + 2]))
            if a[i + 1]=="-":
                d.append(d[i + 1] - int(b[i + 2]))
            if a[i + 1]=="*":
                d.append(d[i + 1] * int(b[i + 2]))
            if a[i + 1]=="/":
                d.append(d[i + 1] / int(b[i + 2]))
        except IndexError:
            pass
    le = int(len(d) - 1)
    alpha(d[le])