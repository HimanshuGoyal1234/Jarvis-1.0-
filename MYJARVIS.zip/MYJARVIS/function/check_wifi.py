from importlib import reload
import random
import psutil
from all_important_functions import _drive_selection_
from all_important_functions import alpha
def is_connected():
    try:
        interfaces = psutil.net_if_stats()
        for interface, stats in interfaces.items():
            if stats.isup and "Wi-Fi" in interface:
                return True
        return False
    except Exception as e:
        print("Error:", e)
        return False
def main():
    if is_connected():
        import Dialogs.Dialog as Dialog
        reload(Dialog)
        Dialog.main(Dialog.online_dlg)
        er = open("G:\\MYJARVIS\\important_things\\input_or_takecommand.txt","w")
        er.write("0")
        er.close()
    else:
        import Dialogs.Dialog as Dialog
        reload(Dialog)
        Dialog.main(Dialog.offline_dlg)
        er = open("G:\\MYJARVIS\\important_things\\input_or_takecommand.txt","w")
        er.write("1")
        er.close()