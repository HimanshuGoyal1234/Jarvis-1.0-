import importlib
import os
import random
from time import sleep

from random import choice

def thinking():
    import function.all_sounds as all
    importlib.reload(all)
    all.thinking()
from all_important_functions import takeCommand

from all_important_functions import alpha
from all_important_functions import _drive_selection_
def main():
    er = f"{_drive_selection_()}\\important_things\\battery_report.html"
    if os.path.exists(er):
        os.remove(er)
    else:
        pass
    thinking()
    sleep(4)
    os.system(f'powercfg /batteryreport /output "{_drive_selection_()}\\important_things\\battery_report.html"')
    alpha("I'll generate a battery report")
    alpha("sir can i open it")
    query = takeCommand().lower()
    if "sure" in query or "open it" in query or "yes" in query:
        os.startfile(f"{_drive_selection_()}\\important_things\\battery_report.html")
        alpha("I'll open it")
    else:
        pass
