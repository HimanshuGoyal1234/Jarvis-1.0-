import os


number = 2
from all_important_functions import _drive_selection_ 
from all_important_functions import alpha
def add_information_to_file(file_path, lin, new_information):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    lines.insert(lin - number, new_information + '\n')
    with open(file_path, 'w') as file:
        file.writelines(lines)
a = open(f'{_drive_selection_()}\\CWH.py', 'r')
e = a.readlines()
def count_alphabet_in_list(alphabet, string_list):
    count = 0
    for string in string_list:
        count += string.count(alphabet)
    return count
result = count_alphabet_in_list("\n", e)
lin = int(result -number)
print(lin)
while True:
    file_path = f'{_drive_selection_()}\\CWH.py'
    new_information = input(": ")
    lin = lin + 1
    print(lin)
    if new_information=="function is completed":
        alpha("(press enter) then JARVIS main file will open and this file is closed")
        input("")
        os.startfile(f"{_drive_selection_()}\\CWH.py")
        exit()
    add_information_to_file(file_path, lin, new_information)