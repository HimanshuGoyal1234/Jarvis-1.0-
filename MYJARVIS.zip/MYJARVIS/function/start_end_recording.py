from pyautogui import * 
def main():
    keyDown("win")
    keyDown("alt")
    press("r")
    sleep(0.5)
    keyUp("alt")
    keyUp("win")
