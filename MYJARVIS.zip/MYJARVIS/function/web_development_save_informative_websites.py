import json
from all_important_functions import takeCommand,alpha
r = "G:\\MYJARVIS\\important_things"
def website(data):
    file_path = f"{r}\\Web_devoplment_website.json"
    try:
        with open(file_path, "r") as file:
            existing_data = json.load(file)
    except FileNotFoundError:
        existing_data = {}
    existing_data.update(data)
    with open(file_path, "w") as file:
        json.dump(existing_data, file, indent=4)
def website_main():
    alpha("Website Name")
    a = takeCommand().lower()
    alpha("Website URL")
    b = takeCommand().lower()
    if a == "":
        a = ""
        b = ""
    if b == "":
        b = ""
        a = ""
    new_data = {
            f"{a}": f"{b}",
    }
    alpha(f"Website Name- {a}\nWebsite URL-{b}")
    website(data=new_data)
    alpha("done Sir")