import subprocess
from all_important_functions import _drive_selection_
from all_important_functions import alpha
def main():
    cmd = "ipconfig"
    output = subprocess.check_output(cmd, shell=True)
    er = output.decode('utf-8')
    a = open("G:\\MYJARVIS\\important_things\\system_info.txt","w")
    re = a.write(er)
    a.close()
    io = str(re)
    ae = open("G:\\MYJARVIS\\important_things\\system_info.txt","r")
    for i in range(47):
        er =ae.readline()
    er = er.replace("   IPv4 Address. . . . . . . . . . . : ","")
    alpha("there is your ipaddress")
    print(f"ipaddress: {er}")
# _config()