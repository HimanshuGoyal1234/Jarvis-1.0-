def custom_binary_conversion(input_string):
    binary_string = ""
    for char in input_string:
        binary_string += "{0:08b}".format(
            ord(char)
        )  # Convert each character to 8-bit binary
    return binary_string
from all_important_functions import _drive_selection_
import importlib
from random import choice
import pyperclip
from all_important_functions import takeCommand
from all_important_functions import alpha
def thinking():
    import function.all_sounds as thinking_
    importlib.reload(thinking_)
    thinking_.thinking()
def error():
    import function.all_sounds as thinking_
    importlib.reload(thinking_)
    thinking_.error()
def main():
    ep = open(f"{_drive_selection_()}\\important_things\\query.txt", "r")
    ep = ep.readline()
    if "convert into binary code" in ep:
        splt = ep.split("convert into binary code ")
    elif "convert into binary" in ep:
        splt = ep.split("convert into binary ")
    try:
        query = splt[1]
        text = query
        binary_text = custom_binary_conversion(text)
        thinking()
        print(text, "is:", binary_text)
        alpha("sir,here it is")
        alpha("sir do you want to send this code to someone")
        a = takeCommand().lower()
        if "sure" in a or "yeah" in a or "yes" in a:
            pyperclip.copy(binary_text)
            alpha("I've copied the binary code to your clipboard")
            alpha("sir now you can send this to anyone")
        else:
            alpha("OKAY,SIR")
            pass
    except IndexError:
        error()
# main()