import importlib
import os
import random
from Automations.automations import (
        first_video,
    move_to_previous_video,
    full_screen,
    play_pause,
)
from all_important_functions import simple_answer
from all_important_functions import _drive_selection_
from all_important_functions import alpha
def random_movies():
    import MMovies.random_movies as random_movies
    importlib.reload(random_movies)
    random_movies.random_movies()
def play_song_dlg():
    import Dialogs.Dialog as Dialog
    importlib.reload(Dialog)
    Dialog.main(Dialog.playsong)
def random_song():
    import Songs.random_song as random_song
    importlib.reload(random_song)
    random_song._random_song()
def play_IGI_game():
    simple_answer()
    import function.play_IGI_game as play_IGI_game
    importlib.reload(play_IGI_game)
    play_IGI_game.play()
def favourite_song():
    alpha("I'm going to play this song")
    import Songs.favourite_song as favourite_song
    importlib.reload(favourite_song)
    favourite_song.favourite_song()
def automations():
    import Automations.automations as automations
    importlib.reload(automations)
    automations.first_video()
def play_next_video():
    import Automations.automations as automations
    importlib.reload(automations)
    automations.move_to_next_video()
def main():
    a = open(f"{_drive_selection_()}\\important_things\\query.txt", "r")
    a = a.readline()
    if a == "play":
        print("ASDD")
    a = a.split("play ")
    query = a[1]
    if "audio books" in query or "audiobooks" in query or "audiobook" in query:
        alpha(f"I am going to play {query}")
        path = "D:\\Audiobook\\Audio BOOKS\\"
        song = os.listdir(path)
        r = len(song)
        randomm = random.randint(0, r - 1)
        os.startfile(os.path.join(path, song[randomm]))
    elif "random moive" in query or "random movies" in query:
        random_movies()
    elif "music playlist" in query:
        os.startfile("G:\\SOME PYTHON FILES\\50 songs randomly play.py")
    elif (
            "random song" in query
        or "random a song" in query
        or "a random song" in query
        or "a song" in query
        or "music" in query
    ):
        play_song_dlg()
        random_song()
    elif "igi game" in query:
        play_IGI_game()
    elif "my favourite song" in query:
        play_song_dlg()
        favourite_song()
    elif "first video" in query:
        first_video()
    elif "next video" in query:
        play_next_video()
    elif "previous video" in query or "last video" in query:
        move_to_previous_video()
    elif "on full screen" in query:
        full_screen()
    else:
        pass
