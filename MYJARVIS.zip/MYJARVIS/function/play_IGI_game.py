from pyautogui import *
def play():
    keyDown("win")
    press("r")
    keyUp("win")
    sleep(1)
    typewrite("F:\\games\\Project_IGI_RIP\\IGI.exe")
    sleep(1)
    press("enter")
# play()