import psutil

from all_important_functions import _drive_selection_ 
from all_important_functions import alpha
def cpu_speed():
    cpu_info = psutil.cpu_freq()
    alpha(f"{cpu_info.current} megahertz")

# cpu_speed()