import importlib
import pywikihow
from all_important_functions import takeCommand
from all_important_functions import alpha
def step_wise():
    import Dialogs.Dialog as Dlg
    importlib.reload(Dlg)
    Dlg.main(Dlg.how_to_do_mode_has_been_activated)
    how = takeCommand().lower()
    max_results = 1
    how_to = pywikihow.search_wikihow(how,max_results)
    assert len(how_to) == 1
    alpha(how_to[0].summary)