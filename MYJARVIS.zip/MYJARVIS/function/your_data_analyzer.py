import json

from all_important_functions import _drive_selection_
from all_important_functions import alpha
def main():
    drive_letter = _drive_selection_()
    query_path = f"{drive_letter}\\important_things\\query.txt"
    with open(query_path, "r") as ep_file:
        query = ep_file.readline().strip()
    common_words = ["jarvis", "can", "you", "tell", "me"]
    for word in common_words:
        query = query.replace(word, "").strip()
    json_file = f"{drive_letter}\\information_of_you\\information_of_me.json"
    with open(json_file, "r") as file:
        data = json.load(file)
    result = data.get(query)
    if result==None:
        pass
    else:
        alpha(result)
