import os


from all_important_functions import _drive_selection_ 
from all_important_functions import alpha

def add_information_to_file(file_path, lin, new_information):
    # Read the content of the file
    with open(file_path, 'r') as file:
        lines = file.readlines()

    # Add new information at the specified line number
    lines.insert(lin - 2, new_information + '\n')
    # Write the modified content back to the file
    with open(file_path, 'w') as file:
        file.writelines(lines)

lin = 19
print(lin)
while True:
    file_path = f"{_drive_selection_()}\\CWH.py"
    new_information = input(": ")
    lin = lin + 1
    print(lin)
    if new_information=="function is completed":
        alpha("(press enter) then new file will open and this file is closed")
        input("")
        os.startfile(f"{_drive_selection_()}\\function\\down_add_new_function.py")
        exit()
    add_information_to_file(file_path, lin, new_information)