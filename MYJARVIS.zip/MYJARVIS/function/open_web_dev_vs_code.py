from pyautogui import *
import os
def main():
    re = "G:\\"
    os.startfile(re)
    sleep(2)
    press("F")
    sleep(1)
    keyDown("shift")
    press("f10")
    keyUp("shift")
    sleep(1)
    press("i")
    press("enter")
main()