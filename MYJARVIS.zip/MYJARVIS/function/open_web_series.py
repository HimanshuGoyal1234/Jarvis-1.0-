import os
from all_important_functions import alpha
re = [
    "All Of Us Are Dead",
    "Jujustu Kaisen 2",
    "Jujutsu Kaisen 1",
    "The Sound of Magic S01",
    "What.If.S02",
]
def main():
    i = open("G:\\MYJARVIS\\important_things\\query.txt", "r")
    io = i.readline()
    if "open web series folder " in io:
        io = io.split("open web series folder ")
    if "open web series founder " in io:
        io = io.split("open web series founder ")
    query = io[1]
    if "all of us are dead" in query:
        path = "E:\\Web-Series"
        song = os.listdir(path)
        r = len(song)
        os.startfile(os.path.join(path, song[0]))
    elif "jujutsu kaisen 2" in query:
        path = "E:\\Web-Series"
        song = os.listdir(path)
        r = len(song)
        os.startfile(os.path.join(path, song[2]))
    elif "jujutsu kaisen 1" in query:
        path = "E:\\Web-Series"
        song = os.listdir(path)
        r = len(song)
        os.startfile(os.path.join(path, song[3]))
    elif "the sound of magic" in query:
        path = "E:\\Web-Series"
        song = os.listdir(path)
        r = len(song)
        os.startfile(os.path.join(path, song[4]))
    elif "what if" in query:
        path = "E:\\Web-Series"
        song = os.listdir(path)
        r = len(song)
        os.startfile(os.path.join(path, song[5]))
    else:
        alpha("folder not found")