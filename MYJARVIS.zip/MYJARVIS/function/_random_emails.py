from faker import Faker

from all_important_functions import _drive_selection_
from all_important_functions import alpha

fake = Faker()
def main():
    random_name = fake.email()
    alpha(f"random email is:- {random_name}")