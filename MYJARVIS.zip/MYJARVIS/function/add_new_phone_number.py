import importlib
import json
from random import choice



from all_important_functions import _drive_selection_
from all_important_functions import takeCommand
from all_important_functions import alpha
def main():
    file_path=f"{_drive_selection_()}\\Phone_Numbers\\saved_phone_number.json"
    alpha("what should i name of them")
    a = takeCommand()
    alpha("Please type, number of them: ")
    b = input("Number:- ")
    
    data = {
        f"{a}":f"{b}"
    }
    data_writing_sound()
    try:
        with open(file_path, 'r') as file:
            existing_data = json.load(file)
    except FileNotFoundError:
        existing_data = {}  
    existing_data.update(data)  
    with open(file_path, 'w') as file:
        json.dump(existing_data, file, indent=4)
    
    alpha("saved contact number successfully")
def data_writing_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.data_writing_sound()