import os
import time
from all_important_functions import alpha,
def main():
    time_ = time.strftime("%F_%H_%M_%S")
    alpha("Tell me Extension of file")
    a = input("")
    poi = f"G:\\MYJARVIS\\your_previous_codes\\{time_}.{a}"
    with open(f"{poi}","a") as f:
        f.writelines("")
    os.system(f"code {poi}")
# main()