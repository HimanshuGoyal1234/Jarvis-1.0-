import os
from all_important_functions import _drive_selection_
def startfunction():
    os.startfile(f"{_drive_selection_()}\\CWH.py")