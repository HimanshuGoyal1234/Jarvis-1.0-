from pyautogui import *
def _screen_shot_():
    keyDown("win")
    keyDown("alt")
    press("prtsc")
    keyUp("alt")
    keyUp("win")