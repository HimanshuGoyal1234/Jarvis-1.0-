from faker import Faker
fake = Faker()
def main():
    fake_email = fake.password()
    fe = f"{fake_email}"
    print(f"'''{fe}'''")