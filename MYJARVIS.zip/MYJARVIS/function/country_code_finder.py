import json
from all_important_functions import _drive_selection_,alpha
def main():
    oi = f"{_drive_selection_()}\\Phone_Numbers\\country_phone_codes\\Country_phone_codes.json"
    ope = open(f"{_drive_selection_()}\\important_things\\query.txt", "r")
    ope = ope.readline()
    splt = str(ope)
    splt = splt.replace("jarvis ", "")
    splt = splt.replace("tell ", "")
    splt = splt.replace("can ", "")
    splt = splt.replace("what ", "")
    splt = splt.replace("is ", "")
    splt = splt.replace("the ", "")
    splt = splt.replace("code ", "")
    splt = splt.replace("country", "")
    splt = splt.replace("of ", "")
    splt = splt.replace(" ", "")
    try:
        with open(oi,"r") as file:
            data = json.load(file)
        alpha(f"Sir, {splt} phone number is {data[splt]}")
    except KeyError:
        alpha("I'm sorry, Number not found")
