import os
import pygetwindow as gw
from time import sleep
from pyautogui import *

open_windows = gw.getAllTitles()
non_blank_titles = []
for title in open_windows:
    if title.strip(): 
        non_blank_titles.append(title)
window_count = len(non_blank_titles)
len_main = window_count - 2


from all_important_functions import takeCommand
from all_important_functions import alpha
def send_message_on_whatsapp__():
    alpha("")
    e = takeCommand().lower()
    alpha("what you want to send")
    what_you_want_to_send = takeCommand().lower()
    whatsapp = "C:\\Users\\ABC\\WhatsApp.lnk"
    os.startfile(whatsapp)
    sleep(6)
    keyDown("alt")
    for i in range(len_main):
        press("tab")
    keyUp("alt")
    sleep(2)
    typewrite(e)
    sleep(1)
    press("tab")
    press("enter")
    sleep(2)
    typewrite(what_you_want_to_send)
    press("enter")
    sleep(2)
    keyDown("alt")
    press("f4")
    keyUp("alt")
    alpha(f"message is sended to {e}")
    alpha("done sir")
# send_message_on_whatsapp__()