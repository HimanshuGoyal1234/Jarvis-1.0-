from os import system
from pyautogui import *
def main():
    system("explorer.exe shell:RecycleBinFolder")
    sleep(1)
    press("enter")
    sleep(1)
    keyDown("ctrl")
    press("a")
    keyUp("ctrl")
    sleep(1)
    press("del")
    sleep(1)
    press("enter")
    sleep(1)
    keyDown("alt")
    press("f4")
    keyUp("alt")
# main()