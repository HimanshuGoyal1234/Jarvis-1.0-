from random import choice
import importlib
import json
import os
from all_important_functions import takeCommand

def copy_file_to_hindi_song_folder_from_download_folder():
    import function.copy_file_to_hindi_song_folder_from_download_folder as copy_file_to_hindi_song_folder_from_download_folder
    importlib.reload(copy_file_to_hindi_song_folder_from_download_folder)
    copy_file_to_hindi_song_folder_from_download_folder.main()
from all_important_functions import _drive_selection_
from all_important_functions import alpha
def main():
    alpha("tell me where you download it\nDownload folder\nyoutube audio download")
    a = takeCommand().lower()
    if "download folder" in a:
        copy_file_to_hindi_song_folder_from_download_folder()
    elif "youtube audio download" in a:
        youtube_audio_download_()
def get_latest_file(path):
    files = os.listdir(path)
    files.sort(key=lambda x: os.path.getmtime(os.path.join(path, x)))
    latest_file = files[-1]
    return os.path.join(path, latest_file)
def youtube_audio_download_():
    folder_path = f"{_drive_selection_()}\\Youtube\\Youtube_audio_downloaded"
    files = os.listdir(folder_path)
    latest_file = None
    latest_modification_time = 0
    for file in files:
        file_path = os.path.join(folder_path, file)
        if os.path.isfile(file_path):
            modification_time = os.path.getmtime(file_path)
            if modification_time > latest_modification_time:
                latest_file = file
                latest_modification_time = modification_time
    if latest_file:
        source_file = os.path.join(folder_path, latest_file)
        destination_file = f"F:\\Songs\\Hindi Song\\{latest_file}"
        with open(source_file, "rb") as source:
            contents = source.read()
            with open(destination_file, "wb") as destination:
                destination.write(contents)
        alpha(f"File '{latest_file}' copied file to hindi song folder SUCCESSFULLY!")
        _path_ = "F:\\Songs\\Hindi Song"
        red = "G:\\MYJARVIS\\Songs\\songs.json"
        latest_song_path = get_latest_file(_path_)
        latest_song_base_name = os.path.basename(latest_song_path)
        new_path = f"F:\\\\Songs\\\\Hindi Song\\\\{latest_song_base_name}"
        green = [
            "sir, what is the name of this song",
            "Excuse me, could you please tell me the title of this song?",
            "can you tell me what is the name of this track",
            "Sir, can you tell me what is the title of this song",
        ]
        alpha(f"{choice[green]}")
        te = takeCommand().lower()
        with open(red, "r", encoding="utf-8") as file:
            existing_data = json.load(file)
        new_data = {f"{te}": f"{new_path}"}
        existing_data.update(new_data)
        with open(red, "w") as file:
            json.dump(existing_data, file, indent=4)

    else:
        alpha("No files found in the folder.")
