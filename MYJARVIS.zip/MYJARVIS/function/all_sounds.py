from playsound import playsound
from random import choice


from all_important_functions import _drive_selection_
def sleep_sound():
    a = [
        f"{_drive_selection_()}\\sounds\\asdsps.mp3",
    ]
    poi = choice(a)
    playsound(poi)
def starting_sound():
    a = [
        f"{_drive_selection_()}\\sounds\\aborting.mp3",
        f"{_drive_selection_()}\\sounds\\aborting2.mp3",
        f"{_drive_selection_()}\\sounds\\aborting3.mp3",
        f"{_drive_selection_()}\\sounds\\aborting4.mp3",
        f"{_drive_selection_()}\\sounds\\aborting5.mp3",
        f"{_drive_selection_()}\\sounds\\aborting6.mp3",
    ]
    poi = choice(a)
    playsound(poi)
def restart_system_sound():
    a = [
        f"{_drive_selection_()}\\sounds\\restart.wav",
        f"{_drive_selection_()}\\sounds\\fast.wav",
    ]
    poi = choice(a)
    playsound(poi)
def wake_sound():
    a = f"{_drive_selection_()}\\sounds\\sdflkj.mp3"
    playsound(a)
def data_writing_sound():
    a = f"{_drive_selection_()}\\sounds\\dataWriting.mp3"
    playsound(a)
def goodbye_sound():
    a = [
        f"{_drive_selection_()}\\sounds\\error.mp3",
        f"{_drive_selection_()}\\sounds\\ending_audio.mp3",
        f"{_drive_selection_()}\\sounds\\ending_audio1.mp3",
        f"{_drive_selection_()}\\sounds\\ending_audio2.mp3",
        f"{_drive_selection_()}\\sounds\\ending_audio3.mp3",
    ]
    poi = choice(a)
    playsound(poi)
def capture_screenshot_sound():
    a = [
        f"{_drive_selection_()}\\sounds\\Capture.mp3",
        f"{_drive_selection_()}\\sounds\\Capture1.mp3",
    ]
    poi = choice(a)
    playsound(poi)
def thinking():
    a = f"{_drive_selection_()}\\sounds\\lkjklk.mp3"
    playsound(a)
def alarm_sound():
    a = f"{_drive_selection_()}\\sounds\\alarm.mp3"
    playsound(a)
def error():
    a = f"{_drive_selection_()}\\sounds\\error.mp3"
    playsound(a)
def clicking():
    a = f"{_drive_selection_()}\\sounds\\button.mp3"
    playsound(a)
def songs_sound():
    a = f"{_drive_selection_()}\\sounds\\mixkit-robot-retract-mechanism-1405.wav"
    playsound(a)
def downloading_sound():
    a = f"{_drive_selection_()}\\sounds\\downloading_audio.mp3"
    playsound(a)
# crack_password_sound()
# clicking()
# error()
# alarm_sound()
# sleep_sound()
# starting_sound()
# restart_system_sound()
# wake_sound()
# data_writing_sound()
# goodbye_sound()
# capture_screenshot_sound()
# thinking()
