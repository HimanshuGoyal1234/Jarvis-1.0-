import time
from all_important_functions import _drive_selection_
def main():
    query = open(f"{_drive_selection_()}\\important_things\\query.txt","r")
    __input__ = query.readline()
    space = " "
    er = f"user_said: {__input__}"
    length = len(er)
    if length<104:
        sub = 104 - length
        for i in range(sub):
            space = space + " "
    r = f"{_drive_selection_()}\\important_things\\histroy_creation.txt"
    time_ = time.strftime("%H:%M:%S")
    date = time.strftime("%D")
    time_date = f"[~~~~({time_})~~~~({date})~~~~]"
    lred = f"{er}{space}{time_date}\n"
    with open(r,"a") as file:
        file.writelines(lred)