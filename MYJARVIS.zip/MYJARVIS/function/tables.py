from all_important_functions import _drive_selection_

def main():
    try:
        # Try to open the file from the path provided by _drive_selection_ function
        drive_path = _drive_selection_()
        file_path = f"{drive_path}\\important_things\\query.txt"
        with open(file_path, "r") as file:
            content = file.readline().strip()
            
        # Split the content based on 'of '
        a = content.split("of ")
        a = a[1]
        # Dictionary mapping ordinal to integer values
        li = {
            "first": 1,
            "second": 2,
            "third": 3,
            "fourth": 4,
            "fifth": 5,
            "sixth": 6,
            "seventh": 7,
            "eighth": 8,
            "nineth": 9,
            "tenth": 10,
        }
        

        if a in li:
            a = li[a]
        else:   
            a = int(a)
        
        if a is not None:
            r = a
            print(r)
            for i in range(9):
                r += a
                print(r)
        else:
            print("Parsed value is not a valid key in the dictionary.")
    
    except FileNotFoundError:
        print("The file was not found. Please check the drive selection path.")
    except Exception as e:
        print(f"An error occurred: {e}")

