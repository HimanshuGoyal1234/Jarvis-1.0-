import importlib
from all_important_functions import _drive_selection_ 
from all_important_functions import alpha
def error():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.error()
def enter_password():
    for i in range(3):
        a = input("enter password:")
        pw_file = open(f"{_drive_selection_()}\\PS\\password.txt","r")
        pw = pw_file.read()
        pw_file.close()
        if (a==pw):
            break
        elif (i==2 and a!=pw):
            error()
            exit()
        elif (a!=pw):
            error()
            print("try again:/ ")
# enter_password()