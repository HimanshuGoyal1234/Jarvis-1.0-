import subprocess
from time import sleep
from pytube import YouTube
from pytube.exceptions import AgeRestrictedError

def chrome(url):
    chrome_path = 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'  # Path to Chrome executable
    subprocess.Popen([chrome_path, url])

from all_important_functions import _drive_selection_ 
from all_important_functions import alpha
def download_video(url, save_path):
    try:
        yt = YouTube(url)
        stream = yt.streams.get_by_resolution("720p")
        print(f"Downloading '{yt.title}'...")
        stream.download(save_path)
        alpha("Download complete.")
    except AgeRestrictedError:
        alpha('The video is age-restricted sir I cannot download it\nI\'ll provide you a link were you can download that video')
        chrome("getn.topsandtees.space/XDEZkzqzxD")
        pass
url = open(f"{_drive_selection_()}\\important_things\\youtube_audio_video.txt","r")
ui = url.readline()
video_url = ui
save_location = f"{_drive_selection_()}\\Youtube\\Youtube_video_downloaded\\"
download_video(video_url, save_location)