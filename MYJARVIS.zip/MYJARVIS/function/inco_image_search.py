import subprocess
from all_important_functions import _drive_selection_
def chrome_incognito(url):
    chrome_path = r"C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe"
    incognito_arg = "--incognito"
    subprocess.Popen([chrome_path, incognito_arg, url])
def chrome_incognito_image_search():
    a = open(f"{_drive_selection_()}\\important_things\\query.txt","r")
    read = a.readline()
    re = read.split("search ")
    er = re[1]
    chrome_incognito(f"https://www.google.com/search?q={er}&udm=2")