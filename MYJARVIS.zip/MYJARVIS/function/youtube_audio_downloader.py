import os
from pytube import YouTube
from moviepy.editor import AudioFileClip
import datetime,pyttsx3
import webbrowser
def _drive_selection_():
    er = open(f"G:\\MYJARVIS\\important_things\\drive.txt", "r")
    re = er.readline()
    return re
def alpha(audio):
    engine = pyttsx3.init("sapi5")
    voices = engine.getProperty("voices")
    engine.setProperty("rate", 180)
    voice = open(f"{_drive_selection_()}\\important_things\\voice.txt", "r")
    voice = voice.readline()
    voice = int(voice)
    engine.setProperty("voice", voices[voice].id)
    ere = f"{audio}..."
    print(ere)
    engine.say(ere)
    engine.runAndWait()
def chrome(url):
    chrome_path = "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe"
    webbrowser.register('chrome', None, webbrowser.BackgroundBrowser(chrome_path))
    webbrowser.get('chrome').open(url)
def download_and_convert_to_mp3(url, save_path):
    try:
        yt = YouTube(url)
        stream = yt.streams.filter(only_audio=True).first()
        alpha(f"Downloading audio from '{yt.title}'...")
        stream.download(output_path=save_path, filename='temp_audio')
        alpha("Download complete.")
        video_clip = AudioFileClip(f"{save_path}/temp_audio")
        video_clip.write_audiofile(f"{save_path}/{yt.title}.mp3")
        video_clip.close()
        alpha("Conversion to MP3 complete.")
        temp_audio_path = os.path.join(save_path, 'temp_audio')
        os.remove(temp_audio_path)
        return yt.title
    except Exception as e:
        alpha("there was an issue downloading the audio")
        alpha("I'm sorry Sir I cannot download this audio because it is an age-restricted video. I'll provide you a link where you can download it.")
        chrome("getn.topsandtees.space/XDEZkzqzxD")
def delete_file(file_path, min_age_hours):
    try:
        if os.path.exists(file_path):
            file_creation_time = os.path.getctime(file_path)
            current_time = datetime.datetime.now().timestamp()
            age_hours = (current_time - file_creation_time) / 3600
            if age_hours >= min_age_hours:
                os.remove(file_path)
                print(f"File '{file_path}' deleted successfully.")
            else:
                pass
        else:
            print(f"File '{file_path}' does not exist.")
    except Exception as e:
        print(f"Error deleting file '{file_path}': {e}")
with open(f"{_drive_selection_()}\\important_things\\youtube_audio_video.txt","r") as urlll:
    ui = urlll.readline()
    video_url = ui 
save_location = f"{_drive_selection_()}\\Youtube\\Youtube_audio_downloaded\\"
video_title = download_and_convert_to_mp3(video_url, save_location)
if video_title is not None:
    file_path_to_delete = os.path.join(save_location, f"{video_title}.mp3")
    minimum_age_hours = 24
    delete_file(file_path_to_delete, minimum_age_hours)