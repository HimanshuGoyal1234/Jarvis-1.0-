from all_important_functions import simple_answer,_drive_selection_,alpha,chrome
import importlib
import subprocess
from time import sleep
from pyautogui import keyDown, keyUp, press
import os
import json
def website():
    simple_answer()
    query = splt
    json_file = f"{_drive_selection_()}\\important_things\\website.json"
    with open(json_file, "r") as file:
        data = json.load(file)
    result = data.get(query)
    if result==None:
        pass
    else:
        chrome(result)
paths = {
        "microsoft edge": "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
    "movies": "F:\\movies",
    "photos folder":"F:\\Pen Drive",
    "chart pattern": "C:\\Users\\ABC\\OneDrive\\Pictures\\5.png",
    "wallpapers folder": "E:\\wallpapers",
    "blender": "E:\\Blender,Editing Software\\Blender\\blender.exe",
    "video editer": "E:\\FlashIntegro\\VideoEditor\\VideoEditor.exe",
    "download":"C:\\Users\\ABC\\Downloads",
    "desktop":"C:\\Users\\ABC\\OneDrive\\Desktop",
    "chrome": "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
    "google chrome": "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
    "whatsapp": "C:\\Users\\ABC\\WhatsApp.lnk",
    "saved screenshot": "C:\\Users\\ABC\\OneDrive\\Videos\\Captures",
    "screenshot folder": "C:\\Users\\ABC\\OneDrive\\Videos\\Captures",
    "captured screenshot folder": "C:\\Users\\ABC\\OneDrive\\Videos\\Captures",
    "telegram": "C:\\Users\\ABC\\Telegram.lnk",
    "games folder": "F:\\games",
    "songs folder": "F:\\Songs\\Hindi Song",
    "computer icon folder": "E:\\Computer_icons_and_more",
    "premium apps folder": "E:\\premium_apps",
    "wallpapers folder": "E:\\wallpapers",
    "g drive": "G:\\",
    "d drive": "D:\\",
    "e drive": "E:\\",
    "f drive": "F:\\",
}
app = {
        "calculator": "calc.exe",
    "notepad": "notepad.exe",
    "settings": "start ms-settings:",
    "bluetooth settings": "start ms-settings-bluetooth:",
    "data usage settings": "start ms-settings:datausage:",
    "network settings": "start ms-settings:network",
    "windows update settings": "start ms-settings:windowsupdate",
    "window update settings": "start ms-settings:windowsupdate",
    "fonts settings": "start ms-settings:fonts",
    "taskbar settings": "start ms-settings:taskbar",
    "themes settings": "start ms-settings:themes",
    "lock screen settings": "start ms-settings:lockscreen",
    "personalization colour settings": "start ms-settings:personalization-colors",
    "personalization settings": "start ms-settings:personalization",
    "wi-fi settings": "start ms-settings:network-wifi",
    "privacy settings": "start ms-settings:privacy",
    "window defender settings": "start ms-settings:windowsdefender",
    "windows defender settings": "start ms-settings:windowsdefender",
    "visual studio code": "code",
    "visual studio": "code",
    "vscode": "code",
    "vs code": "code",
}
your_code_paths = {
        "query code": "code G:\\MYJARVIS\\important_things\\query.txt",
    "battery report code": "code G:\\MYJARVIS\\function\\generate_battery_report.py",
    "google image downlaoder code": "code G:\\MYJARVIS\\function\\google_image_downloader.py",
    "web series code code": "code G:\\MYJARVIS\\function\\open_web_dev_vs_code.py",
    "add new folder code": "code G:\\MYJARVIS\\function\\add_new_folder.py",
    "add new function code": "code G:\\MYJARVIS\\function\\add_new_function.py",
    "add new number code": "code G:\\MYJARVIS\\function\\add_new_number.py",
    "all sounds code": "code G:\\MYJARVIS\\function\\all_sounds.py",
    "automatic save information by google code": "code G:\\MYJARVIS\\function\\automatic_save_information_by_google.py",
    "auto refresh code": "code G:\\MYJARVIS\\function\\auto_refresh.py",
    "calculator code": "code G:\\MYJARVIS\\function\\calculator.py",
    "change name code": "code G:\\MYJARVIS\\function\\change_name.py",
    "change voice code": "code G:\\MYJARVIS\\function\\change_voice.py",
    "check interent speed code": "code G:\\MYJARVIS\\function\\check_interent_speed.py",
    "clean recycle bin code": "code G:\\MYJARVIS\\function\\clean_recycle_bin.py",
    "clean temp code": "code G:\\MYJARVIS\\function\\clean_temp.py",
    "converting into binary code": "code G:\\MYJARVIS\\function\\converting_into_binary.py",
    "copy file in hindi song folder code": "code G:\\MYJARVIS\\function\\copy_file_in_hindi_song_folder.py",
    "copy file to hindi song folder from download folder code": "code G:\\MYJARVIS\\function\\copy_file_to_hindi_song_folder_from_download_folder.py",
    "country code finder code": "code G:\\MYJARVIS\\function\\country_code_finder.py",
    "crack password code": "code G:\\MYJARVIS\\function\\crack_password.py",
    "decode binary code code": "code G:\\MYJARVIS\\function\\decode_binary_code.py",
    "delete anything code": "code G:\\MYJARVIS\\function\\delete_anything.py",
    "down add new function code": "code G:\\MYJARVIS\\function\\down_add_new_function.py",
    "find ipaddress code": "code G:\\MYJARVIS\\function\\find_ipaddress.py",
    "generate battery report code": "code G:\\MYJARVIS\\function\\generate_battery_report.py",
    "get speed of cpu code": "code G:\\MYJARVIS\\function\\get_speed_of_cpu.py",
    "history creation code": "code G:\\MYJARVIS\\function\\history_creation.py",
    "inco image search code": "code G:\\MYJARVIS\\function\\inco_image_search.py",
    "open applications code": "code G:\\MYJARVIS\\function\\open_applications.py",
    "open random dog image code": "code G:\\MYJARVIS\\function\\open_random_dog_image.py",
    "open web dev vs code code": "code G:\\MYJARVIS\\function\\open_web_dev_vs_code.py",
    "open web series code": "code G:\\MYJARVIS\\function\\open_web_series.py",
    "play IGI game code": "code G:\\MYJARVIS\\function\\play_IGI_game.py",
    "play on youtube code": "code G:\\MYJARVIS\\function\\play_on_youtube.py",
    "random books code": "code G:\\MYJARVIS\\function\\random_books.py",
    "save your every code code": "code G:\\MYJARVIS\\function\\save_your_every_code.py",
    "screen shot code": "code G:\\MYJARVIS\\function\\screen_shot.py",
    "search on chatgpt code": "code G:\\MYJARVIS\\function\\search_on_chatgpt.py",
    "search on wikipendia code": "code G:\\MYJARVIS\\function\\search_on_wikipendia.py",
    "search step wise code": "code G:\\MYJARVIS\\function\\search_step_wise.py",
    "send message on instagram code": "code G:\\MYJARVIS\\function\\send_message_on_instagram.py",
    "send message on whatsapp code": "code G:\\MYJARVIS\\function\\send_message_on_whatsapp.py",
    "starting password code": "code G:\\MYJARVIS\\function\\starting_password_.py",
    "start end recording code": "code G:\\MYJARVIS\\function\\start_end_recording.py",
    "translate code": "code G:\\MYJARVIS\\function\\translate.py",
    "wallpaper downloader code": "code G:\\MYJARVIS\\function\\wallpaper_downloader.py",
    "wish me code": "code G:\\MYJARVIS\\function\\wish_me.py",
    "your data analyzer code": "code G:\\MYJARVIS\\function\\your_data_analyzer.py",
    "youtube audio downloader code": "code G:\\MYJARVIS\\function\\youtube_audio_downloader.py",
    "youtube video downloader code": "code G:\\MYJARVIS\\function\\youtube_video_downloader.py",
    "random emails code": "code G:\\MYJARVIS\\function\\_random_emails.py",
    "random name code": "code G:\\MYJARVIS\\function\\_random_name_.py",
    "random passwords code": "code G:\\MYJARVIS\\function\\_random_passwords.py",
    "jokes code": "code G:\\MYJARVIS\\function\\__jokes__.py",
    "pycach code": "code G:\\MYJARVIS\\function\\__pycache__",
    "restart system code": "code G:\\MYJARVIS\\function\\__restart_system__.py",
}
def clicking():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.clicking()
def chrome_incognito(url):
    chrome_path = r"C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe"
    incognito_arg = "--incognito"
    subprocess.Popen([chrome_path, incognito_arg, url])
def chrome_history():
    os.system("start chrome")
    sleep(3)
    keyDown("ctrl")
    press("h")
    keyUp("ctrl")
def open_web_series_folder():
    import function.open_web_series as open_web_series
    importlib.reload(open_web_series)
    open_web_series.main()
def downloading():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.downloading_sound()
def dogs():
    import function.open_random_dog_image as open_random_dog_image
    importlib.reload(open_random_dog_image)
    open_random_dog_image.main()
def play_IGI_game():
    simple_answer()
    import function.play_IGI_game as play_IGI_game
    importlib.reload(play_IGI_game)
    play_IGI_game.play()
def add_new_folder():
    import function.add_new_folder as add_new_folder
    importlib.reload(add_new_folder)
    add_new_folder.main()
ep = open(f"{_drive_selection_()}\\important_things\\query.txt", "r")
ep = ep.readline()
splt = ep.split("open ")
splt = splt[1]
def main():
    website()
    if splt in paths:
        os.startfile(paths[splt])
        simple_answer()
        clicking()
    elif splt in app:
        os.system(app[splt])
        simple_answer()
        clicking()
    elif "incognito mode" in splt:
        chrome_incognito("google.com")
        simple_answer()
        clicking()
    elif "web series folder" in splt or "web series founder" in splt:
        open_web_series_folder()
        clicking()
    elif "website" in splt:
        alpha("type website name")
        er = input()
        chrome(f"{er}")
        clicking()
    elif "chrome history" in splt:
        chrome_history()
        clicking()
    elif (
            "random image of dog" in splt
        or "random pic of dog" in splt
        or "random dog image" in splt
        or "dog image" in splt
        or "dog images" in splt
    ):
        downloading()
        dogs()
        simple_answer()
    elif "add new foldr" in splt:
        add_new_folder()
        simple_answer()
    elif "igi game" in splt:
        play_IGI_game()
        simple_answer()
    elif splt in your_code_paths:
        chrome(your_code_paths[splt])
        simple_answer()
    elif "jarvis folder" in splt:
        os.startfile("G:\\MYJARVIS\\")
    else:
        pass
