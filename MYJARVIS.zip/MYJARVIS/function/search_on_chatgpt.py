import subprocess
from pyautogui import *
from all_important_functions import _drive_selection_
from all_important_functions import alpha
def chrome(url):
    chrome_path = 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'  # Path to Chrome executable
    subprocess.Popen([chrome_path, url])
def main():
    a = open(f"{_drive_selection_()}\\important_things\\query.txt","r")
    readline = a.readline()
    if "search on chat gpt " in readline:
        readline = readline.split("search on chat gpt ")
    elif "search on chat gpd " in readline:
        readline = readline.split("search on chat gpd ")
    _readline_ = readline[1]
    chrome("chat.openai.com")
    sleep(5)
    typewrite(f"{_readline_}")
    sleep(2)
    press("enter")
