import pyttsx3
from all_important_functions import _drive_selection_
from all_important_functions import alpha
engine = pyttsx3.init("sapi5")
voices = engine.getProperty("voices")
engine.setProperty("rate", 180)
voice = open(f"{_drive_selection_()}\\important_things\\voice.txt","r")
voice = voice.readline()
voice = int(voice) + int(1)
def main():
    alpha(f"There are {len(voices)} voices in your Device")
    alpha(f"current voice setted:- {voice}")
    alpha("type which voice do you wanted to set.\nbut set in number\n(like:- 1,2,3)")
    while True:
        try:
            er = input("Voice: ")
            re = int(er) - 1
            poi = str(re)
            break
        except ValueError:
            alpha("Type in Number")
    voffices = open(f"{_drive_selection_()}\\important_things\\voice.txt","w")
    voffices.writelines(poi)
    voffices.close()