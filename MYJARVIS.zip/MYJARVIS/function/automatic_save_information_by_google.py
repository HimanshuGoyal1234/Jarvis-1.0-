from all_important_functions import takeCommand
from all_important_functions import _drive_selection_ 
from all_important_functions import alpha
import importlib,json
def save_info_by_google():
    alpha("what is the question")
    a = takeCommand().lower()
    file_path = f"{_drive_selection_()}\\_google\\google_text.txt"
    r = open(file_path, 'w')
    _text = a[:]
    r.writelines(_text)
    r.close()
    import _google.__google__ as __google___
    importlib.reload(__google___)
    result = __google___._google_search(a)
    alpha(result)
    def create_data(file_path, data):
        try:
            with open(file_path, 'r') as file:
                existing_data = json.load(file)
        except FileNotFoundError:
            existing_data = {}
        existing_data.update(data)
        with open(file_path, 'w') as file:
            json.dump(existing_data, file, indent=4)
    file_path = f"{_drive_selection_()}\\information_of_you\\data.json"
    new_data = {
            f"{a}":f"{result}",
    }
    print(result)
    create_data(file_path, new_data)
 