from faker import Faker

from all_important_functions import alpha

fake = Faker()
def main():
    random_name = fake.name()
    alpha(f"random name, {random_name}")