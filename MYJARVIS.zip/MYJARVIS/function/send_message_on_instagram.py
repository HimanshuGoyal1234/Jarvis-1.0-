from all_important_functions import alpha
from pyautogui import *
import time,os
def send_message_on_instagram():
    alpha("whose one ou want to send message")
    _ID = input("type: ")
    if _ID=="dhammal":
        ID="dhamal.editz_"
    if _ID=="nakul":
        ID="rajput_nakul74"
    if _ID=="veer":
        ID="veers.ingh1984"
    if _ID=="aryan":
        ID = "_aryan_825"
    if _ID =="komal":
        ID = "guptaanushka009"
    if _ID =="our trio":
        ID = "our trio"
    text = input("what you want to send: ") 
    os.startfile("C:\\Users\\ABC\\Instagram.lnk")
    time.sleep(5)
    for i in range(6):
        press("tab")
    press("enter")
    time.sleep(10)
    for i in range(5):
        time.sleep(0.5)
        press("tab")
    press("enter")
    time.sleep(5)
    typewrite(ID)
    time.sleep(3)
    press("tab")
    press("enter")
    press("tab")
    press("enter")
    time.sleep(2)
    typewrite(text)
    press("enter")
    time.sleep(2)
    keyDown("alt")
    press("f4")
    keyUp("alt")
    alpha("Done, sir")