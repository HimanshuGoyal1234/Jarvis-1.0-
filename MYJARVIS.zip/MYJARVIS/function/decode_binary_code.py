import importlib
from time import sleep

def thinking():
    import function.all_sounds as thinking_
    importlib.reload(thinking_)
    thinking_.thinking()



from all_important_functions import alpha
from all_important_functions import _drive_selection_
def main():
    er = open(f"{_drive_selection_()}\\important_things\\decoder_binary_code.txt",'r')
    poi = er.readline()
    binary_text = poi
    binary_bytes = int(binary_text, 2).to_bytes((len(binary_text) + 7) // 8, byteorder='big')
    thinking()
    sleep(1)
    text = binary_bytes.decode('utf-8')
    alpha(f"Converted string: {text}")
# main()