from random import choice, choices
import pyjokes

from all_important_functions import _drive_selection_ 
from all_important_functions import alpha
er = ["😂","🤣","😅"]
def main():
    joke = pyjokes.get_joke()
    alpha(f"{joke}")
    print(choice(er))
