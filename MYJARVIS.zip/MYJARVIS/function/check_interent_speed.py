import speedtest
from all_important_functions import alpha
def test_internet_speed():
    alpha("Ok sir, I'm checking")
    st = speedtest.Speedtest()
    download_speed = st.download() / 1_000_000
    upload_speed = st.upload() / 1_000_000
    alpha(f"Download Speed: {download_speed:.2f} Mbps")
    alpha(f"Upload Speed: {upload_speed:.2f} Mbps")
# test_internet_speed()