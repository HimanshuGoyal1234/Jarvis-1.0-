from pywhatkit import playonyt
from all_important_functions import _drive_selection_
def main():
    ep = open(f"{_drive_selection_()}\\important_things\\query.txt","r")
    ep = ep.readline()
    splt = ep.split("play on youtube ")
    splt = splt[1]
    playonyt(splt)