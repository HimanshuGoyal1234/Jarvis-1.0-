import time
import requests
from PIL import Image
from io import BytesIO
import faker
from all_important_functions import alpha
def main():
    Faker = faker.Faker()
    Faker = Faker.password()
    time_ = time.strftime("%H%M%S")
    time_date = f"{Faker}{time_}"
    r = requests.get(f"{input("")}")
    i = Image.open(BytesIO(r.content))
    fp = open(f"E:\\wallpapers\\{time_date}.jpg","wb")
    i.save(fp)
    fp.close()
    alpha("downloading complete")