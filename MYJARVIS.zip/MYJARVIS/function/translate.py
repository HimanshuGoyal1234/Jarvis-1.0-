import importlib
import time
import googletrans
from gtts import gTTS
import os
import playsound
from random import choice
def thinking():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.thinking()
from all_important_functions import takeCommand
from all_important_functions import _drive_selection_
from all_important_functions import alpha
def main():
    POI = open(f"{_drive_selection_()}\\important_things\\query.txt","r")
    query = POI.readline()
    query = query.split("translate ")
    query = query[1]
    languages= {'english':"en",
    'hindi':"hi",
    'german':"de",
    'russian':"ru"
    }
    alpha("in which language do you want to translate it")
    kl = takeCommand().lower()
    if kl in languages:
        languages = languages[kl]
    else:
        languages = "hi"
    a = googletrans.Translator()
    alpha("Thinking")
    thinking()
    r = a.translate(query,src="auto",dest=languages)
    text = r.text
    print(text)
    try :
        speakgl = gTTS(text=text, lang=languages, slow= True)
        speakgl.save(f"{_drive_selection_()}\\temp\\audio.mp3")
        playsound.playsound(f"G:\\MYJARVIS\\temp\\audio.mp3")
        time.sleep(5)
        os.remove(f"G:\\MYJARVIS\\temp\\audio.mp3")
    except:
        print("Unable to translate")
# main()