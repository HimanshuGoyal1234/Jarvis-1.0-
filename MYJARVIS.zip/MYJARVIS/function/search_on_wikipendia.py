import wikipedia
from all_important_functions import _drive_selection_
def search_wikipedia():
    _query = open(f"{_drive_selection_()}\\important_things\\query.txt","r")
    read_line = _query.readline()
    _split = read_line.split("search on wikipedia ")
    query = _split[1]
    try:
        page = wikipedia.page(query)
        summary_sentences = page.summary.split('.')
        print('. '.join(summary_sentences[:5]) + '.')
    except wikipedia.exceptions.PageError:
        print("Page not found.")
    except wikipedia.exceptions.DisambiguationError as e:
        print(f"Disambiguation Error: {e}")