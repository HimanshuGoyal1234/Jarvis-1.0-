import importlib
import json,pyttsx3
from random import choice
engine = pyttsx3.init("sapi5")
voices = engine.getProperty("voices")
engine.setProperty("rate", 180)
from all_important_functions import alpha,_drive_selection_,takeCommand
def change__name():
    file_path = f"{_drive_selection_()}\\information_of_you\\data.json"
    with open(file_path, "r",encoding="utf-8") as file:
        json_data = json.load(file)
    json1 = json_data["what is your name"].replace("my name is ","")
    last_name = json1
    new_name = takeCommand().capitalize()
    json_data["what is your name"] = json_data["what is your name"].replace(f"{last_name}", f"{new_name}")
    new_word = f"My name is {new_name}"
    json_data["what is your name"] = new_word
    with open(file_path, "w") as file:
        json.dump(json_data, file, indent=4)
    data_writing_sound()
    alpha("changing Name Successfully")
def data_writing_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.data_writing_sound()
# change__name()