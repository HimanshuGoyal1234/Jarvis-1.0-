import importlib
import os
import faker

import time
import requests
from PIL import Image
from io import BytesIO

from all_important_functions import _drive_selection_
def downloading_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.downloading_sound()
from all_important_functions import _drive_selection_
def main():
    downloading_sound()
    time_ = time.strftime("%H%M%S")
    url = "https://dog.ceo/api/breeds/image/random"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        link = data['message']
    else:
        print(response.status_code)
    Faker = faker.Faker()
    Faker = Faker.password()
    time_date = f"{Faker}{time_}"
    r = requests.get(f"{link}")
    i = Image.open(BytesIO(r.content))
    fp = open(f"{_drive_selection_()}\\Dogs\\{time_date}.jpg","wb")
    i.save(fp)
    fp.close()
    os.startfile(f"{_drive_selection_()}\\Dogs\\{time_date}.jpg")