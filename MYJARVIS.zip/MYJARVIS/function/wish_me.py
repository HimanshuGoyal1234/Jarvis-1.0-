import datetime
import importlib
import random
from all_important_functions import alpha
def random_morning_greeting():
    import Dialogs.Dialog as Dialog
    importlib.reload(Dialog)
    Dialog.main(Dialog.good_morningdlg)
def random_afternoon_greeting():
    import Dialogs.Dialog as Dialog
    importlib.reload(Dialog)
    Dialog.main(Dialog.good_afternoondlg)
def random_evening_greeting():
    import Dialogs.Dialog as Dialog
    importlib.reload(Dialog)
    Dialog.main(Dialog.good_eveningdlg)
def __wish_ME__():
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour < 12:
        random_morning_greeting()
    elif hour >= 12 and hour < 18:
        random_afternoon_greeting()
    else:
        random_evening_greeting()
# __wish_ME__()