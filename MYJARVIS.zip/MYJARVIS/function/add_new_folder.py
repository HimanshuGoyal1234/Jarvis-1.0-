import os




from all_important_functions import  _drive_selection_ ,alpha, simple_answer
def main():
    er = {
        "download":"C:\\Users\\ABC\\Downloads\\",
        "desktop":"C:\\Users\\ABC\\OneDrive\\Desktop\\",
        "g drive":"G:\\",
        "d drive":"D:\\",
        "e drive":"E:\\",
        "f drive":"F:\\",
    }
    query = open(f"{_drive_selection_()}\\important_things\\query.txt","r")
    query = query.readline()
    if "create a new folder in" in query:
        split = query.split("create a new folder in ")
    if "add a new folder in" in query:
        split = query.split("add a new folder in ")
    if "add new folder in" in query:
        split = query.split("add new folder in ")
    if "add a folder in" in query:
        split = query.split("add a folder in ")
    if "add folder in" in query:
        split = query.split("add folder in ")
    if "create folder in" in query:
        split = query.split("create folder in ")
    if "create a folder in" in query:
        split = query.split("create a folder in ")
    if "make a folder in" in query:
        split = query.split("create a folder in ")
    d = er[split[1]]
    alpha(f"I'll created a new folder in {split[1]}")
    df = f"{d}\\New folder"
    try:
        os.makedirs(df)
    except:
        try:
            df = f"{d}\\New folder (2)"
            os.makedirs(df)
        except:
            try:
                df = f"{d}\\New folder (3)"
                os.makedirs(df)
            except:
                df = f"{d}\\New folder (4)"
                os.makedirs(df)

    simple_answer()