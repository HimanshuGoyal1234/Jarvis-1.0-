import importlib
import json
from all_important_functions import takeCommand,_drive_selection_,alpha
def save_information_by_me(data):
    file_path=f"{_drive_selection_()}\\birth_day\\festivals.json"
    try:
        with open(file_path, 'r') as file:
            existing_data = json.load(file)
    except FileNotFoundError:
        existing_data = {}
    existing_data.update(data)
    with open(file_path, 'w') as file:
        json.dump(existing_data, file, indent=4+2)
def save_information_by_me_main():
    alpha("what is the name of Festival")
    a = takeCommand()
    alpha("please type, this format"),print("(YYYY-MM-DD)")
    b = input("")
    if a=="":
        a = ""
        b = ""
    if b=="":
        b = ""
        a = ""
    new_data = {f"{a}":f"{b}",}
    alpha(f"Name: {a}\nDate:{b}")
    save_information_by_me(data=new_data)
    data_writing_sound()
    alpha("done Sir")
def data_writing_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.data_writing_sound()