import datetime
import json
import random
from all_important_functions import takeCommand
from all_important_functions import alpha
from all_important_functions import _drive_selection_
file_path = f"{_drive_selection_()}\\festivals\\festivals.json"
with open(file_path, "r") as file:
    json_data = json.load(file)
def is_festival(festival_date):
    today = datetime.datetime.now().date()
    if today.month == festival_date.month and today.day == festival_date.day:
        return True
    else:
        return False
def main():
    with open(f"{_drive_selection_()}\\festivals\\last_date.txt", "r") as file:
        last_printed_date = file.read().strip()
    current_date = datetime.date.today().isoformat()
    if last_printed_date != current_date:
        with open(f"{_drive_selection_()}\\festivals\\last_date.txt", "w") as file:
            file.write(current_date)
        for festival, festival_str in json_data.items():
            festival_ = datetime.datetime.strptime(festival_str, "%m-%d").date()
            if is_festival(festival_):
                alpha_random_list = ["Guess what today is","Can you believe what day it is","Hey, any idea what's so special about today","Ever thought about what date it is","Hey, did you realize what's on the calendar today","Mind if I remind you of something significant about today","Hey there, any clue about the importance of today","Wondering what makes today stand out","Hey, can you sense the significance of today","Any thoughts on what makes today different"]
                answer_random_list = ["Just as a heads-up","Just to keep you informed","Just wanted to let you know","Just a gentle reminder","Just thought I'd share","Just a quick note","Just for your awareness","Just wanted to make you aware","Just in case you weren't aware"]
                re = random.choice(alpha_random_list) 
                answer_random_list = random.choice(answer_random_list) 
                alpha(f"{re}")
                er = takeCommand().lower()
                if "no" in er or "tell me" in er:
                    alpha(f"Happy {festival}")
                elif "skip it" in er or "i don't care" in er:
                    alpha("Okay, sir.")
                    alpha(f"{answer_random_list}, Happy {festival}")
# main()