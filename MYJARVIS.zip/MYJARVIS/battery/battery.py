import random
import psutil


from importlib import reload

from all_important_functions import _drive_selection_
from all_important_functions import alpha
battery = psutil.sensors_battery()
_battery =  battery.percent
plugh = battery.power_plugged
def main():
    if plugh==False:
        pass
    elif plugh==True:
        if _battery < 30:
            import Dialogs.Dialog as full_battery
            reload(full_battery)
            f"{full_battery.main(full_battery.low_b)}"
        elif _battery < 10:
            import Dialogs.Dialog as full_battery
            reload(full_battery)
            f"{full_battery.main(full_battery.last_low)}"
        elif _battery>90:
            import Dialogs.Dialog as full_battery
            reload(full_battery)
            f"{full_battery.main(full_battery._greater_than_90)}"
        
        elif _battery == 100:
            import Dialogs.Dialog as full_battery
            reload(full_battery)
            f"{full_battery.main(full_battery.full_battery)}"
        else:
            pass