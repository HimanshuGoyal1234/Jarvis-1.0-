import importlib
import json
import os
from all_important_functions import alpha
from all_important_functions import _drive_selection_
def movies():
    import MMovies.movies_ as movies_
    importlib.reload(movies_)
    movies_.main()
def main():
    a = open(f"{_drive_selection_()}\\important_things\\query.txt","r")
    a = a.readline()
    a = a.split("play ")
    try:
        a = a[1]
        query = a
        red = f"{_drive_selection_()}\\Songs\\songs.json"
        with open(red,"r",encoding="utf-8") as file:
            load = json.load(file)
        try:
            os.startfile(load[query])
            alpha(f"I am going to play {query}")
        except:
            movies()
    except:
        pass

# main()