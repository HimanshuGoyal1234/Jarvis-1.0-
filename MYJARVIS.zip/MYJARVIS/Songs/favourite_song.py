import random
import os
def get_song_name(song_path):
    return os.path.basename(song_path)
a = random.randint(1, 21)
def favourite_song():
    if a == 1:
        song_path = r"F:\Songs\Slow-Reversed\Sapno Ke Bin Aankhon 👀 Ki Jaise Kimat Koi Na🥀 ： Tum Todo Na ｜ Sad Song #youtub.mp3"
    elif a == 2:
        song_path = r"F:\Songs\Slow-Reversed\Ami Tumake.mp3"
    elif a == 3:
        song_path = r"F:\Songs\Slow-Reversed\Duniyaa [Slowed Reverb].mp3"
    elif a == 4:
        song_path = r"F:\Songs\Slow-Reversed\GF BF ( Lyrics ) - Ft .gurinder seagal ,i wanna take you up and down , round and round lyrics.mp3"
    elif a == 5:
        song_path = r"F:\Songs\Slow-Reversed\Sarri Raat.mp3"
    elif a == 6:
        song_path = r"F:\Songs\Slow-Reversed\Tera_Ban_Jaunga8D_Audio_-_Kabir_S_(getmp3.pro).mp3"
    elif a == 7:
        song_path = r"F:\Songs\Slow-Reversed\Zara_Zara_Bahekta_hai_-_jalraj_Sl_(getmp3.pro).mp3"
    elif a == 8:
        song_path = r"F:\Songs\Slow-Reversed\Pyar Ho (8D Audio).mp3"
    elif a == 9:
        song_path = r"F:\Songs\Slow-Reversed\Teri Jhuki Nazar [Slowed+Reverb] ~ ｜ Mohit Chauhan ｜ Music Lyrics.mp3"
    elif a == 10:
        song_path = r"F:\Songs\Hindi Song\Gulabi Sadi - Sanju Rathore (Lyrics) ｜ Lyrical Bam Marathi.mp3"
    elif a == 11:
        song_path = r"F:\Songs\Hindi Song\Hum To Deewane - Slowed + Reverb ｜ Elvish Yadav ｜ Lofi.mp3"
    elif a == 12:
        song_path = r"F:\Songs\Hindi Song\Timro Pratiksa - Shallum Lama (To Mini)[Official Video].mp4"
    elif a == 13:
        song_path = r"F:\Songs\Hindi Song\Tujhe dekha hai jab se meri aankhe them gayi ⧸⧸ Akela shaphar ⧸⧸ Tu Radha or mai Tera Krishna.mp4"
    elif a == 14:
        song_path = r"F:\Songs\Hindi Song\spotifydown.com - Tere Binaa.mp3"
    elif a == 15:
        song_path = r"F:\Songs\Hindi Song\Full_Video_Song_Sultan_KGF_Ya_(getmp3.pro).mp3"
    elif a == 16:
        song_path = r"F:\Songs\Hindi Song\Tu Ashuqi.mp3"
    elif a == 17:
        song_path = r"F:\Songs\Hindi Song\Mitraz - Akhiyaan (REMIX)  DJ Shadow Dubai  Viral Song.mp3"
    elif a == 18:
        song_path = r"F:\Songs\Hindi Song\JAB TAK Full Video  M.S. DHONI -THE UNTOLD STORY  Armaan Malik, Amaal Mallik Sushant Singh Rajput.mp3"
    elif a == 19:
        song_path = r"F:\Songs\Hindi Song\Atif Aslam Pehli Dafa Song (Full audio lyrics)  Ileana D'Cruz  Last One music....mp3"
    elif a == 20:
        song_path = r"F:\Songs\Hindi Song\khamosiyaan.mp3"
    elif a == 21:
        song_path = r"F:\Songs\Hindi Song\Meri_Banogi_Kya_-_Rito_Riba_Offic_(getmp3.pro).mp4"
    if 'song_path' in locals():
        os.startfile(song_path)
        song_name = get_song_name(song_path)
        print("Playing:", song_name)
