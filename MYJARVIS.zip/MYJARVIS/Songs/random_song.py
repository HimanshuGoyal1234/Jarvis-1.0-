import random,os

def _random_song():
    ii = ["English Song","Hindi Song","DJ","Slow-Reversed","Nakul Song"]
    rr = random.choice(ii)
    if rr == "English Song":
        path = "F:\\Songs\\English Song"
        song = os.listdir(path)
        er = random.choice(song)
        os.startfile(f"{path}\\{er}")
    if rr == "Hindi Song":
        path = "F:\\Songs\\Hindi Song"
        song = os.listdir(path)
        er = random.choice(song)
        os.startfile(f"{path}\\{er}")
    if rr == "DJ":
        path = "F:\\Songs\\DJ"
        song = os.listdir(path)
        er = random.choice(song)
        os.startfile(f"{path}\\{er}")
    if rr == "Slow-Reversed":
        path = "F:\\Songs\\Slow-Reversed"
        song = os.listdir(path)
        er = random.choice(song)
        os.startfile(f"{path}\\{er}")
    if rr == "Nakul Song":
        path = "F:\\Songs\\New folder"
        song = os.listdir(path)
        er = random.choice(song)
        os.startfile(f"{path}\\{er}")
        