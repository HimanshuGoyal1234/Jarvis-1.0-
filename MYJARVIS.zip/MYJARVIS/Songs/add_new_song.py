import json
from all_important_functions import _drive_selection_
def add_song(data):
    file_path = f"{_drive_selection_()}\\Songs\\songs.json"
    try:
        with open(file_path, "r") as file:
            existing_data = json.load(file)
    except FileNotFoundError:
        existing_data = {}
    existing_data.update(data)
    with open(file_path, "w") as file:
        json.dump(existing_data, file, indent=4)
def add_song_main():
    print("what is the question")
    a = input().lower()
    print("what is the answer")
    b = input().lower()
    if a == "":
        a = ""
        b = ""
    if b == "":
        b = ""
        a = ""
    new_data = {
            f"{a}": f"{b}",
    }
    print(f"Question: {a}\nAnswer:{b}")
    add_song(data=new_data)
    print("done Sir")
