import os
rerr =  os.getcwd()
er = open(f"{rerr}\\important_things\\drive.txt","w")
re = er.writelines(rerr)
er.close()
repoipo = f'def _drive_selection_():\n    er = open("{rerr}\\important_things\\drive.txt","r")\n    re = er.readline()\n    return re'
er = open(f"{rerr}\\important_things\\copy_return.txt","w")
po = er.writelines(repoipo)
er.close()