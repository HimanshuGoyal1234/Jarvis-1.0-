from time import sleep
import pyautogui
from all_important_functions import _drive_selection_
ep = open(f"{_drive_selection_()}\\important_things\\query.txt","r")
ep = ep.readline()
def search():
    splt = ep.split("search ")
    try:
        query = splt[1]
        pyautogui.hotkey("/")
        sleep(1)
        pyautogui.typewrite(f"{query}")
        pyautogui.press("enter")
    except:
        pass
def first_video():
    for i in range(81):
        pyautogui.press("tab")
    sleep(0.1)
    pyautogui.press("enter")
def volume_up():
    pyautogui.press('volumeup')
def volume_down():
    pyautogui.press('volumedown')
def seek_backward():
    pyautogui.press('left')
def seek_forward():
    pyautogui.press('right')
def seek_forward_frame():
    pyautogui.press('.')
def seek_to_beginning():
    pyautogui.press('home')
def seek_to_end():
    pyautogui.press('end')
def seek_to_previous_chapter():
    pyautogui.hotkey('ctrl', 'left')
def seek_to_next_chapter():
    pyautogui.hotkey('ctrl', 'right')
def decrease_playback_speed():
    pyautogui.hotkey('shift', ',')
def increase_playback_speed():
    pyautogui.hotkey('shift', '.')
def move_to_next_video():
    pyautogui.hotkey('shift', 'n')
def move_to_previous_video():
    pyautogui.hotkey('shift', 'p')
def check_notifications():
    for i in range(8):
        pyautogui.press('tab')
    pyautogui.press("enter")
def set_window_on_right_side():
    pyautogui.hotkey("win","right")
    pyautogui.press("enter")
def set_window_on_left_side():
    pyautogui.hotkey("win","left")
    pyautogui.press("enter")
def play_pause():
    pyautogui.press("playpause")
def press_enter():
    pyautogui.hotkey("enter")
def toggle_mute_unmute():
    pyautogui.press('m')
def full_screen():
    pyautogui.press('f')
def exit_full_screen():
    pyautogui.press('esc')
def scroll_up():
    pyautogui.press('up')
    pyautogui.press('up')
    pyautogui.press('up')
    pyautogui.press('up')
    pyautogui.press('up')
def scroll_down():
    pyautogui.press('down')
    pyautogui.press('down')
    pyautogui.press('down')
    pyautogui.press('down')
    pyautogui.press('down')
def reload_page():
    pyautogui.hotkey("ctrl","r")
