import importlib
import wikipedia
import json
import requests
from bs4 import BeautifulSoup

from all_important_functions import alpha
def thinking():
    import function.all_sounds as all
    importlib.reload(all)
    all.thinking()
def google_search(query):
    thinking()
    search_result_dlg()
    try:
        url = f"https://www.google.com/search?q={query}"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
        }
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'html.parser')
        search_results = soup.find_all('div', class_='BNeawe')
        
        if search_results:
            result = search_results[0].text
            words = result.split()
            last_word = words[-1]
            if last_word == "Wikipedia":
                try:
                    page = wikipedia.page(query)
                    summary_sentences = page.summary.split('.')
                    result = ('. '.join(summary_sentences[:4]) + '.')  # Print only the first three sentences
                    alpha(result)
                    return result  # Return the result
                except wikipedia.exceptions.PageError:
                    print("Page not found.")
                    return None
                except wikipedia.exceptions.DisambiguationError as e:
                    print(f"Disambiguation Error: {e}")
                    return None
            if last_word != "Wikipedia":
                alpha(result)
                return result  # Return the result
        else:
            print("No search results found.")
            return None
    except requests.RequestException as e:
        print(f"I'm Sorry Sir There Was an issue in search please check your internet connection")
        return None
    except Exception as e:
        print(f"Error: {e}")
        return None
from all_important_functions import _drive_selection_
def save_to_json(query, result):
    file_path = f"{_drive_selection_()}\\information_of_you\\data.json"
    new_data = {
        f"{query}": f"{result}"
    }
    try:
        with open(file_path, 'r') as file:
            existing_data = json.load(file)
    except FileNotFoundError:
        existing_data = {}

    existing_data.update(new_data)

    try:
        with open(file_path, 'w') as file:
            json.dump(existing_data, file, indent=4)
        print("Question:", query)
        print("Answer:", result)
    except Exception as e:
        print(f"Error saving data: {e}")
def search_result_dlg():
    import Dialogs.Dialog as Dialog
    importlib.reload(Dialog)
    Dialog.main(Dialog.search_result)
def main():
    try:
        with open(f"{_drive_selection_()}\\important_things\\query.txt","r") as file:  # Use a relative path or environment variable
            _text = file.readline()
            text = _text.split("search on google ")
            query = text[1]
            result = google_search(query)
            save_to_json(query, result)
    except Exception as e:
        print(f"Error: {e}")

# main()