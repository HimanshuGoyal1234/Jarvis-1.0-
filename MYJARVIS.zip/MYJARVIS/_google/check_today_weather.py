import requests

from all_important_functions import _drive_selection_
from all_important_functions import alpha

def get_temperature(api_key, city):
    """
    Get the current temperature in a given city.
    """
    # Define the URL for the OpenWeatherMap API
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"

    # Try to send a GET request to the URL
    try:
        response = requests.get(url)

        # Check if the request was successful
        if response.status_code == 200:
            # Parse the JSON data
            data = response.json()

            # Get the temperature from the JSON data
            temperature = data['main']['temp']

            # Return the temperature
            return temperature

        # If the request was not successful
        else:
            # Print an error message
            print("Failed to get temperature:", response.status_code)

            # Return None
            return None

    # If an exception occurred
    except Exception as e:
        # Print an error message
        print("An error occurred:", e)

        # Return None
        return None

def main():
    # Open the weather_api_key.txt file and read the API key
    er = open(f"{_drive_selection_()}\\important_things\\weather_api_key.txt")
    key = er.readline()
    api_key = key

    # Set the city to Madhya Pradesh
    city = 'Madhya Pradesh'

    # Call the get_temperature function with the API key and city
    temperature = get_temperature(api_key, city)

    # Check if the temperature is not None
    if temperature is not None:
        # Speak the current temperature
        alpha(f"The current temperature is {temperature}°C.")