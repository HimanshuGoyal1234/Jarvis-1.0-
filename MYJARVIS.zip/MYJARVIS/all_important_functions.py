import datetime
import psutil
import importlib,pyttsx3
import json
from time import sleep
import os
import subprocess
from random import choice, randint
import speech_recognition as sr
def _drive_selection_():
    er = open(f"G:\\MYJARVIS\\important_things\\drive.txt", "r")
    re = er.readline()
    return re
def simple_answer():
    import Dialogs.Dialog as Dialog
    importlib.reload(Dialog)
    return Dialog.main(Dialog.success_open)
def alpha(audio):
    engine = pyttsx3.init("sapi5")
    voices = engine.getProperty("voices")
    engine.setProperty("rate", 180)
    voice = open(f"{_drive_selection_()}\\important_things\\voice.txt", "r")
    voice = voice.readline()
    voice = int(voice)
    engine.setProperty("voice", voices[voice].id)
    ere = f"{audio}..."
    print(ere)
    engine.say(ere)
    engine.runAndWait()
def takeCommand():
    input_or_takecommand = open(
            f"{_drive_selection_()}\\important_things\\input_or_takecommand.txt", "r"
    )
    input_or_takecommand = input_or_takecommand.readline()
    if input_or_takecommand == "0":
        import Dialogs.Dialog as Dialog
        importlib.reload(Dialog)
        first = choice(Dialog.listening_dlg)
        second = choice(Dialog.recognizing_dlg)
        third = choice(Dialog.say_that_again_dlg)
        champu =  first
        _champu = second
        _champu_ = third
        while True:
            r = sr.Recognizer()
            count = 0
            while count < 3:
                with sr.Microphone() as source:
                    print(f"{champu}")
                    r.pause_threshold = 1
                    r.energy_threshold = 10000
                    audio = r.listen(source)
                try:
                    print(_champu)
                    query = r.recognize_google(audio, language="en-in")
                    print(f"User said: {query}\n")
                    return query.lower()
                except Exception as e:
                    count += 1
                    print(f"{_champu_}\n")
            _sleep()
    elif input_or_takecommand=="1":
        query = input()
        return query.lower()
def delete_file_folder():
    alpha("sir, give me a path")
    import function.delete_anything as delete_anything
    importlib.reload(delete_anything)
    delete_anything.delete()
def send_message_on_whatsapp():
    import function.send_message_on_whatsapp as send_message_on_whatsapp
    importlib.reload(send_message_on_whatsapp)
    send_message_on_whatsapp.send_message_on_whatsapp__()
def send_message_on_instagram():
    import function.send_message_on_instagram as send_message_on_instagram
    importlib.reload(send_message_on_instagram)
    send_message_on_instagram.send_message_on_instagram()
def _search_wikipedia():
    import function.search_on_wikipendia as search_on_wikipendia
    importlib.reload(search_on_wikipendia)
    search_on_wikipendia.search_wikipedia()
def find_phone_number():
    import Phone_Numbers.checking_phone_number as checking_phone_number
    importlib.reload(checking_phone_number)
    checking_phone_number.main()
def add_new_number():
    import function.add_new_phone_number as add_new_phone_number
    importlib.reload(add_new_phone_number)
    add_new_phone_number.main()
def checking_phone_number_directly():
    import Phone_Numbers.checking_phone_number_directly as checking_phone_number_directly
    importlib.reload(checking_phone_number_directly)
    checking_phone_number_directly.main()
def chrome(url):
    chrome_path = 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'  # Path to Chrome executable
    subprocess.Popen([chrome_path, url])
def _play_song_():
    import Songs.songs as songs
    importlib.reload(songs)
    songs.main()
def save_your_code():
    import function.save_your_every_code as save_your_every_code
    importlib.reload(save_your_every_code)
    save_your_every_code.main()
def Google_search():
    import _google.__google__ as __google___
    importlib.reload(__google___)
    __google___.main()
def wishMe():
    import function.wish_me as wish_me
    importlib.reload(wish_me)
    wish_me.__wish_ME__()
def alarm_when_sleep():
    os.startfile(f"{_drive_selection_()}\\alarm\\alarm__.py")
def _sleep():
    import Dialogs.Dialog as Dialog
    importlib.reload(Dialog)
    alpha(f"{choice(Dialog.___sleep)}")
    query_for_alarm = open("G:\\MYJARVIS\\alarm\\query_for_alarm.txt", "r")
    queryoo = query_for_alarm.readline()
    if queryoo == "":
        pass
    else:
        alarm_when_sleep()
    sleep_sound()
    input("")
    wake_sound()
    sleep(1)
    er = [
            "I'll Wake Up, Sir",
        "I'll Gently Awaken, Sir",
        "I shall rise from slumber, Sir.",
        "I Shall Awaken,  At Your Command",
        "I Shall Arise,  At Your Command",
        "I'll Arise Promptly,  Upon Your Call",
    ]
    er = choice(er)
    alpha(er)
def change_name():
    alpha(f"{simple_answer()} which name do you like to call me")
    import function.change_name as change_name
    importlib.reload(change_name)
    change_name.change__name()
def save_information_by_me(data):
    file_path = f"{_drive_selection_()}\\information_of_you\\information_of_me.json"
    try:
        with open(file_path, "r") as file:
            existing_data = json.load(file)
    except FileNotFoundError:
        existing_data = {}
    existing_data.update(data)
    with open(file_path, "w") as file:
        json.dump(existing_data, file, indent=4)
def save_information_by_me_main():
    alpha("what is the question")
    a = takeCommand().lower()
    alpha("what is the answer")
    b = takeCommand().lower()
    if a == "":
        a = ""
        b = ""
    if b == "":
        b = ""
        a = ""
    new_data = {
            f"{a}": f"{b}",
    }
    print(f"Question: {a}\nAnswer:{b}")
    save_information_by_me(data=new_data)
    data_writing_sound()
    alpha("done Sir")
def Data_analyzer():
    def load_data(file_path):
        with open(file_path, "r", encoding="utf-8") as file:
            data = json.load(file)
        return data
    def main():
        try:
            data_file = f"{_drive_selection_()}\\information_of_you\\data.json"
            data = load_data(data_file)
            query = open("G:\\MYJARVIS - Copy\\important_things\\query.txt","r")
            query = query.readline()
            user_input = query
            handle_query(user_input, data)
        except Exception as e:
            print(f"An error occurred: {e}")
    def handle_query(query, data):
        if query.lower() in data:
            alpha(data[query.lower()])
        else:
            pass
    main()
def your_data_analyzer():
    import function.your_data_analyzer as your_data_analyzer
    importlib.reload(your_data_analyzer)
    your_data_analyzer.main()
def battery_percentage():
    battery = psutil.sensors_battery()
    return battery.percent
def alarm():
    _query_name = open(f"{_drive_selection_()}\\alarm\\query_name.txt", "r")
    query_name = _query_name.readline()
    r = open(f"{_drive_selection_()}\\alarm\\query_for_alarm.txt", "r")
    current_time = r.readline()
    er = open(f"{_drive_selection_()}\\alarm\\query_for_alarm.txt", "r")
    if current_time == "":
        return
    dfdf = er.readline()
    current_time = current_time[13:-5]
    time_components = current_time.split(":")
    hours = int(time_components[0])
    minutes = int(time_components[1])
    am_pm = dfdf[18:]
    if am_pm == "p.m.":
        if hours >= 1 and hours <= 11:
            hours += 12
    print(f"alarm set: {hours}:{minutes} {am_pm}")
    now = datetime.datetime.now()
    if now.hour == hours and now.minute >= minutes:
        er = open(f"{_drive_selection_()}\\alarm\\query_for_alarm.txt", "w")
        er.write("")
        er.close()
        alarm_sound()
        sleep(5)
        alpha(f"{query_name} sir\nalarm time sir")
def get_cpu_speed():
    import function.get_speed_of_cpu as get_cpu_speed_of_cpu
    importlib.reload(get_cpu_speed_of_cpu)
    get_cpu_speed_of_cpu.cpu_speed()
def __close__():
    file_path = f"{_drive_selection_()}\\important_things\\query.txt"
    with open(file_path, "r") as file:
        contents = file.read()
        words = contents.split()
        pi = words[-1]
        err = pi
        _dict_ = {
                "mpc": "mpc-hc64",
            "notepad": "notepad",
            "chrome": "chrome",
            "photos": "Microsoft.Photos",
            "calculator": "calculatorapp",
            "vlc": "vlc",
            "photos": "photosapp",
            "edge": "msedge",
            "instagram": "msedge",
            "camera": "windowscamera",
            "whatsapp": "whatsapp",
            "store": "winstore.app",
        }
        er = _dict_[err]
        os.system(f"taskkill /f /im {er}.exe")
def _screen_shot():
    import function.screen_shot as screen_shot
    importlib.reload(screen_shot)
    screen_shot._screen_shot_()
    capture_screenshot()
    alpha("captured screen shot")
def __restart_system():
    import function.__restart_system__ as __restart_system__
    importlib.reload(__restart_system__)
    __restart_system__.startfunction()
    exit()
def _add_birth_day():
    import birth_day.add_birth_day as add_birth_day
    importlib.reload(add_birth_day)
    add_birth_day.save_information_by_me_main()
def birth_day_finder():
    alpha("tell me these things")
    import birth_day.birth_day_left_finder as birth_day_left_finder
    importlib.reload(birth_day_left_finder)
    birth_day_left_finder.birth_Day_finder()
def specials_birth_day_and_festivals():
    import birth_day.tells_birth_day_of_specials as tells_birth_day_of_specials
    importlib.reload(tells_birth_day_of_specials)
    tells_birth_day_of_specials.main()
    import festivals.main_file as main_file
    importlib.reload(main_file)
    main_file.main()
def tell_birthdate():
    import birth_day.tells_birth_day_of_specials as tell_birthdate
    importlib.reload(tell_birthdate)
    tell_birthdate.tell_birthdate()
def to_my_birthday():
    import birth_day.birth_day_left_finder as birth_day_left_finder
    importlib.reload(birth_day_left_finder)
    birth_day_left_finder.how_many_days_left_to_my_birth_day()
def _add_festival():
    import festivals.add_festival as add_festival
    importlib.reload(add_festival)
    add_festival.save_information_by_me_main()
def _starting_password():
    import function.starting_password_ as starting_password_
    importlib.reload(starting_password_)
    starting_password_.enter_password()
def youtube_video_download_():
    er = open(f"{_drive_selection_()}\\important_things\\youtube_audio_video.txt", "w")
    alpha(f"{simple_answer()} \nplease copy url of than video then i download it  ")
    inn = input("URL: ")
    er.writelines(inn)
    er.close()
    os.startfile(f"{_drive_selection_()}\\function\\youtube_video_downloader.py")
def youtube_audio_download_():
    er = open(f"{_drive_selection_()}\\important_things\\youtube_audio_video.txt", "w")
    alpha(f"{simple_answer()} \nplease copy url of than audio then i download it")
    inn = input("URL: ")
    er.writelines(inn)
    er.close()
    os.startfile(f"{_drive_selection_()}\\function\\youtube_audio_downloader.py")
    alpha("downloading start")
def search_step_wise():
    import function.search_step_wise as search_step_wise
    importlib.reload(search_step_wise)
    search_step_wise.step_wise()
def user_name_of_instagram():
    import instagram.user_name as user_name
    importlib.reload(user_name)
    user_name.user_name()
def instagram_dp_downloader():
    import instagram.instagram_dp_downloader as instagram_dp_downloader
    importlib.reload(instagram_dp_downloader)
    instagram_dp_downloader.download_instagram_dp()
def random_reels_on_instagram():
    import instagram.random_funny_reels as random_funny_reels
    importlib.reload(random_funny_reels)
    random_funny_reels.random_reel()
def news():
    er = open(f"{_drive_selection_()}\\query.txt", "r")
    read_line = er.readline()
    split = read_line.split("news of ")
    whose = split[1]
    if whose == "ipl":
        import news.IPL as IPL
        importlib.reload(IPL)
        IPL.IPL()
    elif whose == "banking and finance":
        import news.banking_and_finance as banking_and_finance
        importlib.reload(banking_and_finance)
        banking_and_finance.banking_finance()
    elif whose == "market":
        import news.market as market
        importlib.reload(market)
        market.IPL()
    else:
        print("🤔")
        pass
def _movies_():
    import MMovies.movies_ as movies_
    importlib.reload(movies_)
    movies_.main()
def random_tell_movies_for_watch():
    import MMovies.random_movies_for_watch as random_movies_for_watch
    importlib.reload(random_movies_for_watch)
    random_movies_for_watch.main()
def play_IGI_game():
    alpha(f"{simple_answer()}")
    import function.play_IGI_game as play_IGI_game
    importlib.reload(play_IGI_game)
    play_IGI_game.play()
    _sleep()
def search_on_chatgpt():
    import function.search_on_chatgpt as search_on_chatgpt
    importlib.reload(search_on_chatgpt)
    search_on_chatgpt.main()
def check_weather_today():
    import _google.check_today_weather as check_today_weather
    importlib.reload(check_today_weather)
    check_today_weather.get_temperature()
def copy_file_in_hindi_song_folder():
    import function.copy_file_in_hindi_song_folder as copy_file_in_hindi_song_folder
    importlib.reload(copy_file_in_hindi_song_folder)
    copy_file_in_hindi_song_folder.main()
def clean_temp():
    import function.clean_temp as clean_temp
    importlib.reload(clean_temp)
    clean_temp.main()
def clean_recycle_bin():
    import function.clean_recycle_bin as clean_recycle_bin
    importlib.reload(clean_recycle_bin)
    clean_recycle_bin.main()
def open_web_dev_vs_code():
    import function.open_web_dev_vs_code as open_web_dev_vs_code
    importlib.reload(open_web_dev_vs_code)
    open_web_dev_vs_code.main()
def refresh_my_window():
    import function.auto_refresh as auto_refresh
    importlib.reload(auto_refresh)
    auto_refresh.main()
def start_end_recording():
    import function.start_end_recording as start_end_recording
    importlib.reload(start_end_recording)
    start_end_recording.main()
def _425():
    import os, random
    path = "F:\\zMMM\\Nandu"
    list_ = os.listdir(path)
    r = len(list_)
    main = randint(0, r - 1)
    os.startfile(os.path.join(path, list_[main]))
def open_web_series_folder():
    import function.open_web_series as open_web_series
    importlib.reload(open_web_series)
    open_web_series.main()
def check_internet_speed():
    import function.check_interent_speed as check_interent_speed
    importlib.reload(check_interent_speed)
    check_interent_speed.test_internet_speed()
def open_applications():
    import function.open_applications as open_applications
    importlib.reload(open_applications)
    open_applications.main()
def jokes():
    import function.__jokes__ as __jokes__
    importlib.reload(__jokes__)
    __jokes__.main()
def play_on_yt():
    alpha(f"{simple_answer()}")
    import function.play_on_youtube as play_on_youtube
    importlib.reload(play_on_youtube)
    play_on_youtube.main()
def voice_changer():
    alpha(f"{simple_answer()} ")
    import function.change_voice as change_voice
    importlib.reload(change_voice)
    change_voice.main()
def audio_books():
    import function.random_books as random_books
    importlib.reload(random_books)
    random_books.main()
def history_creation():
    import function.history_creation as history_creation
    importlib.reload(history_creation)
    history_creation.main()
def translate():
    import function.translate as translate
    importlib.reload(translate)
    translate.main()
def binary_converter():
    import function.converting_into_binary as converting_into_binary
    importlib.reload(converting_into_binary)
    converting_into_binary.main()
def decode_binary_code_():
    alpha(
            f"{simple_answer()}  \nplease copy binary code then i convert it into text"
    )
    a = input(">>>")
    er = open(f"{_drive_selection_()}\\important_things\\decoder_binary_code.txt", "w")
    poi = er.writelines(a)
    er.close()
    import function.decode_binary_code as decode_binary_code
    importlib.reload(decode_binary_code)
    decode_binary_code.main()
def sleep_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.sleep_sound()
def starting_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.starting_sound()
def restart_system_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.restart_system_sound()
def wake_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.wake_sound()
def data_writing_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.data_writing_sound()
def goodbye_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.goodbye_sound()
def capture_screenshot():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.capture_screenshot_sound()
def alarm_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.alarm_sound()
def battery():
    import battery.battery as __battery
    importlib.reload(__battery)
    __battery.main()
def find_my_ip_address():
    import function.find_ipaddress as find_ipaddress
    importlib.reload(find_ipaddress)
    find_ipaddress.main()
def crack_password():
    import function.crack_password as crack_password
    importlib.reload(crack_password)
    crack_password.main()
def battery_report():
    import function.generate_battery_report as generate_battery_report
    importlib.reload(generate_battery_report)
    generate_battery_report.main()
def generate_random_name():
    import function._random_name_ as _random_name_
    importlib.reload(_random_name_)
    _random_name_.main()
def generate_random_email():
    import function._random_emails as _random_emails
    importlib.reload(_random_emails)
    _random_emails.main()
def generate_random_password():
    import function._random_passwords as _random_passwords
    importlib.reload(_random_passwords)
    _random_passwords.main()
def country_code_finder():
    import function.country_code_finder as country_code_finder
    importlib.reload(country_code_finder)
    country_code_finder.main()
def goodBYE():
    import Dialogs.Dialog as Dialog
    importlib.reload(Dialog)
    alpha(choice(Dialog.goodbye))
def check_wifi():
    import function.check_wifi as wifi
    importlib.reload(wifi)
    wifi.main()
def welcome():
    import Dialogs.Dialog as Dialog
    importlib.reload(Dialog)
    alpha(choice(Dialog.welcomedlg))
