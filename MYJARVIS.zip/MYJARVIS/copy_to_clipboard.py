import pyperclip

def copy_file__clipboard(file_path):
    with open(file_path, 'r') as file:
        content = file.read()
        pyperclip.copy(content)
from all_important_functions import _drive_selection_
input = input("g: ")
if input=="alpha":
    copy_file__clipboard(f'{_drive_selection_()}\\temp\\free_contant.txt')
if input=="takecommand":
    copy_file__clipboard(f'{_drive_selection_()}\\temp\\f.txt')
if input=="query":
    copy_file__clipboard(f'{_drive_selection_()}\\temp\\query.txt')
if input=="def":
    copy_file__clipboard(f'{_drive_selection_()}\\temp\\def.txt')
if input=="chrome":
    copy_file__clipboard(f'{_drive_selection_()}\\temp\\chrome.txt')
if input=="return":
    copy_file__clipboard(f'{_drive_selection_()}\\temp\\return.txt')
if input=="simple answer":
    copy_file__clipboard(f'{_drive_selection_()}\\temp\\simple_answer.txt')
if input=="drive selection":
    copy_file__clipboard(f'{_drive_selection_()}\\temp\\drive_selection.txt')
