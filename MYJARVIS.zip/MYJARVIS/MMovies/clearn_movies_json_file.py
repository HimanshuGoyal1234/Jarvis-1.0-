import json

with open('G:\\MYJARVIS\\MMovies\\tranding_movies\\random_movies.json', 'r',encoding="utf-8") as file:
    data = json.load(file)
def remove_duplicate_objects(data):
    seen = set()
    result = []
    for obj in data:
        obj_tuple = tuple(sorted(obj.items()))
        if obj_tuple not in seen:
            result.append(obj)
            seen.add(obj_tuple)
    return result
cleaned_data = remove_duplicate_objects(data)
with open('cleaned_file.json', 'w',encoding="utf-8") as file:
    json.dump(cleaned_data, file, indent=4)
