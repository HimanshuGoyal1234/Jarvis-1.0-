import json
import random

from all_important_functions import _drive_selection_
from all_important_functions import alpha
def main():
    with open(f'{_drive_selection_()}\\MMovies\\tranding_movies\\random_movies.json', 'r',encoding="utf-8") as json_file:
        existing_data = json.load(json_file)
    num_random_entries = 1
    for _ in range(num_random_entries):
        alpha("i hope sir do you like this movie")
        random_movie = random.choice(existing_data)
        print(f"Title: {random_movie["title"]}")
        print(f"Year: {random_movie["year"]}")
        print(f"Rating: {random_movie["rating"]}")
        print(f"Views: {random_movie["views"]}")
# main()