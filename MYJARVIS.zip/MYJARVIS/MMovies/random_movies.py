import os
import random
def random_movies():
    
    directories = ["MOVIES"]
    chosen_directory = random.choice(directories)
    if chosen_directory=="MOVIES":
        path = "E:\\Movies\\"
        movies = os.listdir(path)
        random_index = random.randint(0, len(movies) - 1)
        random_movie = movies[random_index]
        os.startfile(os.path.join(path, random_movie))
        print(os.path.basename(random_movie))