while True:
    random_movie = {
        "title": input("title: "),
        "year": input("year: "),
        "time": input("time: "),
        "rating": input("rating: "),
        "views": input("views: "),
    }
    r = "},"
    p = "{"
    we = open("data.txt", "a", encoding="utf-8")
    we.writelines(
        f'{p}"title": "{random_movie["title"]}","year":"{random_movie["year"]}","rating":"{random_movie["rating"]}","views":"{random_movie["views"]}"{r}'
    )
    we.close()