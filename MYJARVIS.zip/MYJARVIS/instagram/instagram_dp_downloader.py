import importlib
import instaloader
import requests

from all_important_functions import _drive_selection_ 
from all_important_functions import alpha
def download_instagram_dp():
    folder_path = f"{_drive_selection_()}\\instagram\\instagram_DPs"
    alpha("please give username of that instagram id")
    username = input("")
    loader = instaloader.Instaloader()
    try:
        profile = instaloader.Profile.from_username(loader.context, username)
        dp_url = profile.profile_pic_url
        response = requests.get(dp_url)
        if response.status_code == 200:
            with open(f"{folder_path}/{username}_dp.jpg", 'wb') as f:
                f.write(response.content)
                data_writing_sound()
                alpha(f"Profile picture downloaded successfully")
                alpha("done Sir")
        else:
            alpha("Failed to download profile picture")
    except instaloader.exceptions.ProfileNotExistsException:
        alpha(f"Profile {username} does not exist.")
def data_writing_sound():
    import function.all_sounds as all_sounds
    importlib.reload(all_sounds)
    all_sounds.data_writing_sound()