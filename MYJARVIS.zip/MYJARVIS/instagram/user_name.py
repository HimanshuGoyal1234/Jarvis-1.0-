import subprocess
import webbrowser
from time import sleep


def chrome(url):
    chrome_path = 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'  # Path to Chrome executable
    subprocess.Popen([chrome_path, url])
from all_important_functions import _drive_selection_ 
from all_important_functions import alpha
def user_name():
    alpha("enter the user_name of profile")
    er = input("")
    chrome(f"instagram.com/{er}")