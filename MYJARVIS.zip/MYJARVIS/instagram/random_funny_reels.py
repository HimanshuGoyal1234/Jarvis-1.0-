import webbrowser
import random
from all_important_functions import _drive_selection_
def random_reel():
    with open(f'{_drive_selection_()}\\instagram\\instagram_links.txt', 'r') as file:
        instagram_links = file.readlines()
    instagram_links = [link.strip() for link in instagram_links]
    random_link = random.choice(instagram_links)
    webbrowser.open(random_link)